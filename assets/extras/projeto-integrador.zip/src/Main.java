import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Estoque estoque = new Estoque();
        Scanner entrada = new Scanner(System.in);
        System.out.println("Comandos: receber ID QTD | retirar ID QTD | listar | fim");
        while (entrada.hasNextLine()) {
            String linha = entrada.nextLine().trim();
            if (linha.equals("fim")) break;
            if (linha.equals("listar")) {
                System.out.println(estoque.consultar());
                continue;
            }
            String[] partes = linha.split("\s+");
            if (partes.length != 3 ||
                    !(partes[0].equals("receber") || partes[0].equals("retirar"))) {
                System.out.println("Comando inválido");
                continue;
            }
            try {
                int quantidade = Integer.parseInt(partes[2]);
                if (partes[0].equals("receber")) {
                    estoque.receber(partes[1], quantidade);
                    System.out.println("Recebimento concluído");
                } else {
                    System.out.println(estoque.retirar(partes[1], quantidade)
                        ? "Retirada concluída" : "Quantidade indisponível");
                }
            } catch (NumberFormatException erro) {
                System.out.println("Quantidade deve ser inteira");
            } catch (IllegalArgumentException erro) {
                System.out.println(erro.getMessage());
            } catch (ArithmeticException erro) {
                System.out.println("Quantidade excede o limite do estoque");
            }
        }
    }
}