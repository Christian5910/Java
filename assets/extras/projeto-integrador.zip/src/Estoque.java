import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

public class Estoque {
    private final Map<String, Integer> itens = new LinkedHashMap<>();
    private static void validar(String id, int quantidade) {
        if (id == null || id.trim().isEmpty() || quantidade <= 0) {
            throw new IllegalArgumentException("Dados inválidos");
        }
    }
    public void receber(String id, int quantidade) {
        validar(id, quantidade);
        int novo = Math.addExact(itens.getOrDefault(id, 0), quantidade);
        itens.put(id, novo);
    }
    public boolean retirar(String id, int quantidade) {
        validar(id, quantidade);
        int atual = itens.getOrDefault(id, 0);
        if (quantidade > atual) return false;
        itens.put(id, atual - quantidade);
        return true;
    }
    public Map<String, Integer> consultar() {
        return Collections.unmodifiableMap(new LinkedHashMap<>(itens));
    }
}
