import java.util.Map;

public class Testes {
    static int cenarios;
    static void conferir(boolean condicao, String nome) {
        if (!condicao) throw new AssertionError(nome);
        cenarios++;
    }
    public static void main(String[] args) {
        Estoque estoque = new Estoque();
        estoque.receber("A", 5);
        conferir(estoque.consultar().get("A") == 5, "Receber em estoque vazio");
        estoque.receber("A", 2);
        conferir(estoque.consultar().get("A") == 7, "Acumular recebimento");
        conferir(estoque.retirar("A", 3), "Aceitar retirada parcial");
        conferir(!estoque.retirar("A", 5) && estoque.consultar().get("A") == 4,
            "Recusa deve preservar saldo");
        Map<String, Integer> fotografia = estoque.consultar();
        estoque.receber("A", 1);
        conferir(fotografia.get("A") == 4, "Fotografia independente");
        boolean protegeu = false;
        try { fotografia.put("A", 99); }
        catch (UnsupportedOperationException esperado) { protegeu = true; }
        conferir(protegeu && estoque.consultar().get("A") == 5, "Proteger consulta");
        conferir(new Estoque().consultar().isEmpty(), "Instâncias independentes");
        conferir(estoque.retirar("A", 5) && estoque.consultar().get("A") == 0,
            "Aceitar retirada exata");
        boolean invalido = false;
        try { estoque.receber(" ", 1); }
        catch (IllegalArgumentException esperado) { invalido = true; }
        conferir(invalido, "Recusar identificador vazio");
        invalido = false;
        try { estoque.receber("A", 0); }
        catch (IllegalArgumentException esperado) { invalido = true; }
        conferir(invalido && estoque.consultar().get("A") == 0, "Recusar zero");
        estoque.receber("LIMITE", Integer.MAX_VALUE);
        boolean overflow = false;
        try { estoque.receber("LIMITE", 1); }
        catch (ArithmeticException esperado) { overflow = true; }
        conferir(overflow && estoque.consultar().get("LIMITE") == Integer.MAX_VALUE,
            "Overflow deve preservar estado");
        System.out.println(cenarios + " cenários verificados");
    }
}