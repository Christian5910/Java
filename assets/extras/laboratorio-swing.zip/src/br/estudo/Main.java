package br.estudo;
import java.awt.*;
import java.awt.event.KeyEvent;
import javax.swing.*;
public class Main {
    public static void main(String[] args) { SwingUtilities.invokeLater(Main::abrir); }
    private static void abrir() {
        JFrame janela=new JFrame("Notas de estudo");
        janela.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JPanel formulario=new JPanel(new BorderLayout(12,12));
        formulario.setBorder(BorderFactory.createEmptyBorder(20,20,20,20));
        JTextField nota=new JTextField(14);
        JLabel rotulo=new JLabel("Nota (0 a 10):"); rotulo.setLabelFor(nota);
        JLabel resultado=new JLabel("Informe a nota para conferir a situação.");
        resultado.getAccessibleContext().setAccessibleName("Resultado da avaliação");
        JButton conferir=new JButton("Conferir"); conferir.setMnemonic(KeyEvent.VK_C);
        conferir.addActionListener(evento -> {
            try { resultado.setText(Nota.avaliar(nota.getText())); }
            catch (IllegalArgumentException erro) { resultado.setText(erro.getMessage()); nota.requestFocusInWindow(); }
        });
        JPanel linha=new JPanel(new FlowLayout(FlowLayout.LEADING)); linha.add(rotulo); linha.add(nota); linha.add(conferir);
        formulario.add(linha,BorderLayout.NORTH);formulario.add(resultado,BorderLayout.CENTER);
        janela.setContentPane(formulario);janela.getRootPane().setDefaultButton(conferir);
        janela.pack();janela.setMinimumSize(janela.getSize());janela.setLocationRelativeTo(null);janela.setVisible(true);
    }
}
