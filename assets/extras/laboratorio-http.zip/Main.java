import com.sun.net.httpserver.HttpServer;
import java.net.InetSocketAddress;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Main {
    public static void main(String[] args) throws Exception {
        HttpServer servidor = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 0);
        ExecutorService executor = Executors.newFixedThreadPool(2);
        servidor.setExecutor(executor);
        servidor.createContext("/", troca -> {
            int status;
            String corpo;
            if (!troca.getRequestMethod().equals("GET")) {
                status = 405; corpo = "{\"erro\":\"metodo\"}";
                troca.getResponseHeaders().set("Allow", "GET");
            } else if (troca.getRequestURI().getPath().equals("/estado")) {
                status = 200; corpo = "{\"estado\":\"pronto\"}";
            } else {
                status = 404; corpo = "{\"erro\":\"rota\"}";
            }
            byte[] bytes = corpo.getBytes(StandardCharsets.UTF_8);
            troca.getResponseHeaders().set("Content-Type", "application/json; charset=UTF-8");
            troca.sendResponseHeaders(status, bytes.length);
            try (java.io.OutputStream saida = troca.getResponseBody()) { saida.write(bytes); }
            finally { troca.close(); }
        });
        try {
            servidor.start();
            HttpClient cliente = HttpClient.newBuilder()
                .connectTimeout(Duration.ofSeconds(3)).build();
            for (String rota : new String[]{"/estado", "/ausente"}) {
                URI uri = URI.create("http://127.0.0.1:" + servidor.getAddress().getPort() + rota);
                HttpRequest pedido = HttpRequest.newBuilder(uri)
                    .timeout(Duration.ofSeconds(5)).GET().build();
                HttpResponse<String> resposta = cliente.send(pedido,
                    HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
                System.out.println("GET " + rota + ": " + resposta.statusCode() + " " + resposta.body());
            }
        } finally {
            servidor.stop(0);
            executor.shutdownNow();
        }
    }
}