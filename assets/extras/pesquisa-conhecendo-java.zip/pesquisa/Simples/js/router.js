/* ================================================================
   CONHECENDO JAVA — router.js
   Hash-based SPA router para carregar páginas em /pages/*.html
   ================================================================ */

const ROUTES = {
  ''            : 'home',
  'home'        : 'home',
  'historia'    : 'historia',
  'sintaxe'     : 'sintaxe',
  'estrutura'   : 'estrutura',
  'poo'         : 'poo',
  'fundamentos' : 'fundamentos',
  'conexoes'    : 'conexoes',
  'recursos'    : 'recursos',
  'certificacoes': 'certificacoes',
  'download'    : 'download',
  'runner'      : 'runner',
};

/* Page content cache */
const PAGE_CACHE = {};

/* ── Current page ── */
let currentPage = null;

/* ── Navigate ── */
async function navigate(page) {
  page = page || '';
  const route = ROUTES[page] || 'home';
  history.pushState(null, '', '#' + route);
  await loadPage(route);
}

/* ── Load page content from /pages/*.html ── */
async function loadPage(route) {
  if (currentPage === route) return;
  currentPage = route;

  /* Runner is part of home or a dedicated section */
  const target = route === 'runner' ? 'runner' : route;

  showLoader(true);

  try {
    let html;
    if (PAGE_CACHE[target]) {
      html = PAGE_CACHE[target];
    } else {
      const res = await fetch(`pages/${target}.html`);
      if (!res.ok) throw new Error('Page not found');
      html = await res.text();
      PAGE_CACHE[target] = html;
    }

    /* Mount content */
    const container = document.getElementById('page-container');
    container.innerHTML = html;

    /* Run page scripts */
    const scripts = container.querySelectorAll('script');
    scripts.forEach(oldScript => {
      const s = document.createElement('script');
      if (oldScript.src) s.src = oldScript.src;
      else s.textContent = oldScript.textContent;
      document.body.appendChild(s);
      oldScript.remove();
    });

    /* Scroll to top */
    window.scrollTo({ top: 0, behavior: 'smooth' });

    /* Update nav active */
    updateNav(route);

    /* Re-init interactive components */
    initComponents();

    /* TOC observer */
    initTOC();

  } catch (err) {
    document.getElementById('page-container').innerHTML = `
      <div style="padding:4rem 1.5rem;text-align:center;color:var(--text-m)">
        <div style="font-size:3rem;margin-bottom:1rem">☕</div>
        <h2 style="margin-bottom:.5rem">Página não encontrada</h2>
        <p>A seção "<strong>${route}</strong>" ainda está sendo preparada.</p>
        <button onclick="navigate('home')" class="btn-primary" style="margin-top:1.5rem">
          <i class="fa fa-home"></i> Voltar ao Início
        </button>
      </div>`;
  } finally {
    showLoader(false);
  }
}

/* ── Update nav highlight ── */
function updateNav(route) {
  document.querySelectorAll('.nav-links a, #mobile-nav a').forEach(el => {
    el.classList.toggle('active', el.dataset.page === route);
  });
}

/* ── Loader ── */
function showLoader(show) {
  const el = document.getElementById('page-loader');
  if (el) el.classList.toggle('show', show);
}

/* ── Handle browser back/forward ── */
window.addEventListener('popstate', () => {
  const hash = location.hash.replace('#', '') || 'home';
  loadPage(ROUTES[hash] || 'home');
});

/* ── Initial load ── */
document.addEventListener('DOMContentLoaded', () => {
  const hash = location.hash.replace('#', '') || 'home';
  loadPage(ROUTES[hash] || 'home');
});
