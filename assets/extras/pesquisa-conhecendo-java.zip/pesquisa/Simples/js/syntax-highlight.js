/* ================================================================
   CONHECENDO JAVA — syntax-highlight.js
   Lightweight Java syntax highlighter (no deps)
   ================================================================ */

(function() {
  'use strict';

  const KEYWORDS = new Set([
    'abstract','assert','boolean','break','byte','case','catch','char',
    'class','const','continue','default','do','double','else','enum',
    'extends','final','finally','float','for','goto','if','implements',
    'import','instanceof','int','interface','long','native','new',
    'package','private','protected','public','record','return','sealed',
    'short','static','strictfp','super','switch','synchronized','this',
    'throw','throws','transient','try','var','void','volatile','while',
    'yield','permits','with'
  ]);

  const CONTROL = new Set([
    'return','break','continue','throw','yield'
  ]);

  const TYPES = new Set([
    'String','Integer','Long','Double','Float','Boolean','Byte','Short','Char',
    'Object','Number','Math','System','Thread','Runnable','Exception',
    'RuntimeException','Error','Throwable','StringBuilder','StringBuffer',
    'List','ArrayList','LinkedList','Map','HashMap','TreeMap','LinkedHashMap',
    'Set','HashSet','TreeSet','LinkedHashSet','Queue','Deque','ArrayDeque',
    'Optional','Stream','Collectors','Arrays','Collections','Iterator',
    'Iterable','Comparable','Comparator','Function','Predicate','Consumer',
    'Supplier','BiFunction','BiConsumer','UnaryOperator','BinaryOperator',
    'CompletableFuture','Future','ExecutorService','Executors',
    'InputStream','OutputStream','Reader','Writer','File','Path','Files',
    'var','void'
  ]);

  const BOOL = new Set(['true','false','null']);

  /* ── Tokenize a line ── */
  function highlightLine(line) {
    let result = '';
    let i = 0;
    const len = line.length;

    while (i < len) {
      // Line comment
      if (line[i] === '/' && line[i+1] === '/') {
        result += `<span class="cmt">${escHtml(line.slice(i))}</span>`;
        break;
      }

      // String literal
      if (line[i] === '"') {
        let j = i + 1;
        while (j < len && !(line[j] === '"' && line[j-1] !== '\\')) j++;
        j++;
        result += `<span class="str">${escHtml(line.slice(i, j))}</span>`;
        i = j;
        continue;
      }

      // Char literal
      if (line[i] === "'") {
        let j = i + 1;
        while (j < len && !(line[j] === "'" && line[j-1] !== '\\')) j++;
        j++;
        result += `<span class="str">${escHtml(line.slice(i, j))}</span>`;
        i = j;
        continue;
      }

      // Annotation
      if (line[i] === '@') {
        let j = i + 1;
        while (j < len && /\w/.test(line[j])) j++;
        result += `<span class="ann">${escHtml(line.slice(i, j))}</span>`;
        i = j;
        continue;
      }

      // Number
      if (/[0-9]/.test(line[i]) || (line[i] === '-' && /[0-9]/.test(line[i+1] || ''))) {
        let j = i;
        if (line[j] === '-') j++;
        while (j < len && /[0-9._xXbBlLfFdD]/.test(line[j])) j++;
        result += `<span class="num">${escHtml(line.slice(i, j))}</span>`;
        i = j;
        continue;
      }

      // Word (keyword / type / identifier)
      if (/[a-zA-Z_$]/.test(line[i])) {
        let j = i;
        while (j < len && /[\w$]/.test(line[j])) j++;
        const word = line.slice(i, j);

        // Peek: is next char '(' → method call?
        const next = line.slice(j).trimStart();
        const isMethod = next.startsWith('(');
        const isClass  = /^[A-Z]/.test(word);

        if (BOOL.has(word)) {
          result += `<span class="bool">${word}</span>`;
        } else if (CONTROL.has(word)) {
          result += `<span class="kw2">${word}</span>`;
        } else if (word === 'package' || word === 'import') {
          result += `<span class="pkg">${word}</span>`;
        } else if (word === 'interface') {
          result += `<span class="iface">${word}</span>`;
        } else if (KEYWORDS.has(word)) {
          result += `<span class="kw">${word}</span>`;
        } else if (TYPES.has(word)) {
          result += `<span class="tp">${word}</span>`;
        } else if (isMethod) {
          result += `<span class="fn">${word}</span>`;
        } else if (isClass) {
          result += `<span class="cls">${word}</span>`;
        } else {
          result += escHtml(word);
        }
        i = j;
        continue;
      }

      // Operators
      if (/[+\-*/%=!<>&|^~?:.]/.test(line[i])) {
        result += `<span class="op">${escHtml(line[i])}</span>`;
        i++;
        continue;
      }

      // Punctuation
      if (/[{}()\[\];,]/.test(line[i])) {
        result += `<span class="pun">${escHtml(line[i])}</span>`;
        i++;
        continue;
      }

      result += escHtml(line[i]);
      i++;
    }
    return result;
  }

  /* ── Highlight block comment ── */
  function highlightCode(code) {
    const lines  = code.split('\n');
    const result = [];
    let inBlock  = false;
    let inString = false;

    for (let line of lines) {
      if (!inBlock) {
        // Check for opening block comment
        if (line.includes('/*') && !line.slice(0, line.indexOf('/*')).includes('"')) {
          if (line.includes('*/')) {
            // Inline block comment
            const s = line.indexOf('/*');
            const e = line.indexOf('*/') + 2;
            result.push(
              highlightLine(line.slice(0, s)) +
              `<span class="cmt">${escHtml(line.slice(s, e))}</span>` +
              highlightLine(line.slice(e))
            );
          } else {
            inBlock = true;
            const s = line.indexOf('/*');
            result.push(
              highlightLine(line.slice(0, s)) +
              `<span class="cmt">${escHtml(line.slice(s))}</span>`
            );
          }
        } else {
          result.push(highlightLine(line));
        }
      } else {
        if (line.includes('*/')) {
          inBlock = false;
          const e = line.indexOf('*/') + 2;
          result.push(`<span class="cmt">${escHtml(line.slice(0, e))}</span>` + highlightLine(line.slice(e)));
        } else {
          result.push(`<span class="cmt">${escHtml(line)}</span>`);
        }
      }
    }
    return result.join('\n');
  }

  function escHtml(s) {
    return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
  }

  /* ── Auto-highlight all pre.code-block inside .auto-highlight ── */
  function autoHighlight() {
    document.querySelectorAll('.auto-hl pre.code-block, pre.code-block[data-lang="java"]')
      .forEach(pre => {
        if (pre.dataset.highlighted) return;
        pre.innerHTML = highlightCode(pre.textContent);
        pre.dataset.highlighted = '1';
      });
  }

  /* Export */
  window.JavaHighlight = { highlightCode, autoHighlight };

  /* Run on DOMContentLoaded and after page loads */
  document.addEventListener('DOMContentLoaded', autoHighlight);
})();
