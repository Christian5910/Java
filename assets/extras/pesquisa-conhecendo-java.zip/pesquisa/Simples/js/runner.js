/* ================================================================
   CONHECENDO JAVA — runner.js (100% LOCAL — SEM API!)
   Playground que executa Java simulado no browser
   ================================================================ */

/* ── SAÍDAS PRÉ-DEFINIDAS PARA EXEMPLOS CONHECIDOS ──────────── */
const KNOWN_OUTPUTS = {
  hello: `Compilando OlaMundo.java...
Compilação bem-sucedida.
Executando...

Olá, Mundo! ☕
Java versão: 21.0.4

Programa finalizado em 23 ms.`,

  fibonacci: `Compilando Fibonacci.java...
Compilação bem-sucedida.
Executando...

Sequência de Fibonacci até 15 termos:
0, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377

Programa finalizado em 18 ms.`,

  poo: `Compilando Animal.java...
Compilação bem-sucedida.
Executando...

=== Fazenda Java ===
Cachorro diz: Au au! 🐕
Gato diz: Miau! 🐈
Pato diz: Quack! 🦆

Programa finalizado em 31 ms.`,

  lambda: `Compilando StreamsDemo.java...
Compilação bem-sucedida.
Executando...

Pares ao quadrado: [4, 16, 36, 64, 100]
Soma de 1 a 10: 55
Quantidade de pares: 5

Programa finalizado em 42 ms.`,

  record: `Compilando RecordsDemo.java...
Compilação bem-sucedida.
Executando...

P1: Ponto[x=3.0, y=4.0]
Distância da origem: 5.0
P1 == P2? false

Pessoa: Pessoa[nome=Ana, idade=28, email=ana@java.com]
Nome: Ana

Programa finalizado em 28 ms.`,

  collections: `Compilando CollectionsDemo.java...
Compilação bem-sucedida.
Executando...

Linguagens JVM: [Clojure, Groovy, Java, Kotlin, Scala]

Versions LTS:
  Java 8 LTS   → 2014
  Java 11 LTS  → 2018
  Java 17 LTS  → 2021
  Java 21 LTS  → 2023
  Java 25 LTS  → 2025

Set ordenado: [Clojure, Groovy, Java, Kotlin, Scala]

Programa finalizado em 35 ms.`
};

/* ── CÓDIGOS DE EXEMPLO ─────────────────────────────────────── */
const EXAMPLES = {
  hello: `public class OlaMundo {
    public static void main(String[] args) {
        System.out.println("Olá, Mundo! ☕");
        System.out.println("Java versão: " + 
            System.getProperty("java.version"));
    }
}`,

  fibonacci: `public class Fibonacci {
    public static void main(String[] args) {
        int n = 15;
        System.out.println("Sequência de Fibonacci até " + n + " termos:");
        
        int a = 0, b = 1;
        for (int i = 0; i < n; i++) {
            System.out.print(a + (i < n-1 ? ", " : ""));
            int temp = a + b;
            a = b;
            b = temp;
        }
        System.out.println();
    }
}`,

  poo: `public class Animal {
    private String nome;
    private String som;
    
    public Animal(String nome, String som) {
        this.nome = nome;
        this.som  = som;
    }
    
    public void fazerSom() {
        System.out.println(nome + " diz: " + som);
    }
    
    public static void main(String[] args) {
        Animal[] animais = {
            new Animal("Cachorro", "Au au! 🐕"),
            new Animal("Gato",     "Miau! 🐈"),
            new Animal("Pato",     "Quack! 🦆")
        };
        
        System.out.println("=== Fazenda Java ===");
        for (Animal a : animais) {
            a.fazerSom();
        }
    }
}`,

  lambda: `import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class StreamsDemo {
    public static void main(String[] args) {
        List<Integer> numeros = Arrays.asList(1,2,3,4,5,6,7,8,9,10);
        
        // Pares ao quadrado
        List<Integer> resultado = numeros.stream()
            .filter(n -> n % 2 == 0)
            .map(n -> n * n)
            .collect(Collectors.toList());
        
        System.out.println("Pares ao quadrado: " + resultado);
        
        int soma = numeros.stream()
            .reduce(0, Integer::sum);
        System.out.println("Soma de 1 a 10: " + soma);
        
        long pares = numeros.stream()
            .filter(n -> n % 2 == 0)
            .count();
        System.out.println("Quantidade de pares: " + pares);
    }
}`,

  record: `public class RecordsDemo {
    record Ponto(double x, double y) {
        double distanciaOrigem() {
            return Math.sqrt(x * x + y * y);
        }
    }
    record Pessoa(String nome, int idade, String email) {}
    
    public static void main(String[] args) {
        var p1 = new Ponto(3.0, 4.0);
        var p2 = new Ponto(0.0, 0.0);
        
        System.out.println("P1: " + p1);
        System.out.printf("Distância da origem: %.1f%n",
            p1.distanciaOrigem());
        System.out.println("P1 == P2? " + p1.equals(p2));
        
        var pessoa = new Pessoa("Ana", 28, "ana@java.com");
        System.out.println("\\nPessoa: " + pessoa);
        System.out.println("Nome: " + pessoa.nome());
    }
}`,

  collections: `import java.util.*;

public class CollectionsDemo {
    public static void main(String[] args) {
        List<String> linguagens = new ArrayList<>(
            Arrays.asList("Java", "Kotlin", "Scala", "Groovy")
        );
        linguagens.add("Clojure");
        linguagens.sort(String::compareTo);
        System.out.println("Linguagens JVM: " + linguagens);
        
        Map<String, Integer> versoes = new LinkedHashMap<>();
        versoes.put("Java 8 LTS",  2014);
        versoes.put("Java 11 LTS", 2018);
        versoes.put("Java 17 LTS", 2021);
        versoes.put("Java 21 LTS", 2023);
        versoes.put("Java 25 LTS", 2025);
        
        System.out.println("\\nVersions LTS:");
        versoes.forEach((v, y) -> 
            System.out.printf("  %-12s → %d%n", v, y));
        
        Set<String> unicos = new TreeSet<>(linguagens);
        unicos.add("Java");
        System.out.println("\\nSet ordenado: " + unicos);
    }
}`
};

/* ── NORMALIZAÇÃO DE CÓDIGO (remove espaços extras) ─────────── */
function normalizeCode(code) {
  return code.replace(/\s+/g, ' ').trim();
}

/* ── ESCAPE HTML ─────────────────────────────────────────────── */
function escapeHtml(s) {
  return s.replace(/&/g, '&amp;')
          .replace(/</g, '&lt;')
          .replace(/>/g, '&gt;');
}

/* ── ANÁLISE LOCAL DE CÓDIGO CUSTOMIZADO ────────────────────── */
function analyzeCustomCode(code) {
  const lines = code.split('\n');
  let output = [];
  let className = 'Programa';
  let errors = [];
  
  // Verifica se tem classe
  const classMatch = code.match(/public\s+class\s+(\w+)/);
  if (!classMatch) {
    errors.push(`${lines[0].trim()}:1: error: class, interface, or enum expected`);
    return { type: 'error', output: errors.join('\n') };
  }
  className = classMatch[1];
  
  // Verifica se tem main
  if (!code.includes('public static void main')) {
    errors.push(`Error: Main method not found in class ${className}, please define the main method as:`);
    errors.push(`   public static void main(String[] args)`);
    return { type: 'error', output: errors.join('\n') };
  }
  
  // Extrai printlns e prints simulando a execução
  const printRegex = /System\.out\.println\((.*?)\)/g;
  const printNoLnRegex = /System\.out\.print\((.*?)\)/g;
  
  let match;
  while ((match = printRegex.exec(code)) !== null) {
    let content = match[1].trim();
    if (content.startsWith('"') && content.endsWith('"')) {
      content = content.slice(1, -1)
        .replace(/\\n/g, '\n')
        .replace(/\\t/g, '\t')
        .replace(/\\"/g, '"');
    }
    output.push(content);
  }
  
  while ((match = printNoLnRegex.exec(code)) !== null) {
    let content = match[1].trim();
    if (content.startsWith('"') && content.endsWith('"')) {
      content = content.slice(1, -1);
    }
    if (output.length > 0) {
      output[output.length - 1] = (output[output.length - 1] || '') + content;
    } else {
      output.push(content);
    }
  }
  
  if (output.length === 0) {
    output.push('(Programa executado sem saída visível — nenhum System.out.println detectado)');
  }
  
  return {
    type: 'success',
    output: output.join('\n'),
    className: className
  };
}

/* ── FORMATAÇÃO DA SAÍDA COM CORES ──────────────────────────── */
function formatOutput(text) {
  return text.split('\n').map(line => {
    if (line.includes('ERRO') || line.includes('error:') || line.includes('Exception')) {
      return `<span class="out-err">${escapeHtml(line)}</span>`;
    }
    if (line.startsWith('Compilando') || line.startsWith('Executando') || line.startsWith('Compilação')) {
      return `<span class="out-info">${escapeHtml(line)}</span>`;
    }
    if (line.startsWith('Programa finalizado')) {
      return `<span style="color:var(--warning)">${escapeHtml(line)}</span>`;
    }
    return escapeHtml(line);
  }).join('\n');
}

/* ── FUNÇÃO PRINCIPAL DE EXECUÇÃO ───────────────────────────── */
function runJavaCode() {
  const input  = document.getElementById('java-input');
  const output = document.getElementById('output-box');
  const status = document.getElementById('runner-status');
  const btn    = document.getElementById('run-btn');
  
  if (!input || !output) return;
  
  const code = input.value.trim();
  if (!code) {
    output.innerHTML = '<span class="out-info">// Digite algum código Java para executar.</span>';
    return;
  }
  
  btn.disabled = true;
  btn.innerHTML = '⏳ Compilando...';
  if (status) status.textContent = 'Processando...';
  output.innerHTML = '<span class="out-info">Compilando e executando...</span>';
  
  // Simula delay de compilação (realismo)
  setTimeout(() => {
    // 1. Verifica se é um código conhecido
    let result = null;
    for (const [key, exampleCode] of Object.entries(EXAMPLES)) {
      if (normalizeCode(code) === normalizeCode(exampleCode)) {
        result = {
          type: 'success',
          output: KNOWN_OUTPUTS[key]
        };
        break;
      }
    }
    
    // 2. Se não é conhecido, analisa localmente
    if (!result) {
      result = analyzeCustomCode(code);
    }
    
    // 3. Formata e exibe a saída
    if (result.type === 'error') {
      output.innerHTML = `<span class="out-err">${escapeHtml(result.output)}</span>`;
      if (status) {
        status.textContent = '❌ Erro de compilação';
        status.style.color = 'var(--error)';
      }
    } else {
      output.innerHTML = formatOutput(result.output);
      if (status) {
        status.textContent = '✅ Executado com sucesso';
        status.style.color = 'var(--success)';
      }
    }
    
    btn.disabled = false;
    btn.innerHTML = '▶ Executar';
  }, 300);
}

/* ── LIMPAR RUNNER ──────────────────────────────────────────── */
function clearRunner() {
  const output = document.getElementById('output-box');
  const status = document.getElementById('runner-status');
  if (output) output.innerHTML = '<span class="out-info">// Saída limpa. Execute um novo código.</span>';
  if (status) { status.textContent = ''; status.style.color = ''; }
}

/* ── CARREGAR EXEMPLO ───────────────────────────────────────── */
function loadExample(name) {
  const input = document.getElementById('java-input');
  if (!input) return;
  if (EXAMPLES[name]) input.value = EXAMPLES[name];
}

/* ── CARREGAR EXEMPLO E SCROLL ──────────────────────────────── */
function loadAndScroll(name) {
  loadExample(name);
  document.getElementById('java-input')?.scrollIntoView({ 
    behavior: 'smooth', 
    block: 'center' 
  });
}

/* ── COPIAR OUTPUT ──────────────────────────────────────────── */
function copyOutput() {
  const box = document.getElementById('output-box');
  if (!box) return;
  const text = box.innerText || box.textContent;
  navigator.clipboard.writeText(text).then(() => {
    const btn = event?.target?.closest('button');
    if (btn) {
      const orig = btn.innerHTML;
      btn.innerHTML = '✓ Copiado!';
      setTimeout(() => btn.innerHTML = orig, 2000);
    }
  });
}

/* ── ATALHOS DE TECLADO ─────────────────────────────────────── */
document.addEventListener('keydown', (e) => {
  const input = document.getElementById('java-input');
  if (!input) return;
  
  // Tab = 2 espaços
  if (document.activeElement === input && e.key === 'Tab') {
    e.preventDefault();
    const start = input.selectionStart;
    const end   = input.selectionEnd;
    input.value = input.value.substring(0, start) + '  ' + input.value.substring(end);
    input.selectionStart = input.selectionEnd = start + 2;
  }
  
  // Ctrl+Enter = executar
  if (e.ctrlKey && e.key === 'Enter') {
    runJavaCode();
  }
});

/* ── CARREGA EXEMPLO PADRÃO AO ABRIR ────────────────────────── */
setTimeout(() => {
  const input = document.getElementById('java-input');
  if (input && !input.value.trim()) {
    loadExample('hello');
  }
}, 100);