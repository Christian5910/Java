/* ================================================================
   CONHECENDO JAVA — app.js (MPA puro)
   Funcionalidades globais compartilhadas por todas as páginas
   ================================================================ */

/* ── THEME TOGGLE ───────────────────────────────────────────── */
(function initTheme() {
  const saved = localStorage.getItem('theme');
  const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
  const theme = saved || (prefersDark ? 'dark' : 'light');
  document.documentElement.setAttribute('data-theme', theme);
})();

document.getElementById('theme-btn')?.addEventListener('click', () => {
  const current = document.documentElement.getAttribute('data-theme');
  const next = current === 'light' ? 'dark' : 'light';
  document.documentElement.setAttribute('data-theme', next);
  localStorage.setItem('theme', next);
});

/* ── SCROLL TOPBAR + SCROLL TOP BUTTON ──────────────────────── */
window.addEventListener('scroll', () => {
  const topbar = document.getElementById('topbar');
  const scrollTop = document.getElementById('scroll-top');
  if (topbar) topbar.classList.toggle('scrolled', window.scrollY > 20);
  if (scrollTop) scrollTop.classList.toggle('show', window.scrollY > 300);
});

document.getElementById('scroll-top')?.addEventListener('click', () => {
  window.scrollTo({ top: 0, behavior: 'smooth' });
});

/* ── MOBILE MENU TOGGLE ─────────────────────────────────────── */
document.getElementById('menu-btn')?.addEventListener('click', () => {
  const menu = document.getElementById('mobile-menu');
  if (menu) menu.toggleAttribute('hidden');
});

/* ── MOBILE DROPDOWNS (accordion) ───────────────────────────── */
document.querySelectorAll('.mobile-dropdown-toggle').forEach(btn => {
  btn.addEventListener('click', (e) => {
    e.preventDefault();
    btn.parentElement.classList.toggle('open');
  });
});

/* ── ACCORDIONS ─────────────────────────────────────────────── */
document.querySelectorAll('.acc-head').forEach(head => {
  head.addEventListener('click', () => {
    head.parentElement.classList.toggle('open');
  });
});

/* ── TABS ───────────────────────────────────────────────────── */
document.querySelectorAll('.tab-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    const container = btn.closest('.tabs');
    if (!container) return;
    const panelId = btn.dataset.panel;
    
    container.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
    container.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
    
    btn.classList.add('active');
    const panel = container.querySelector('#' + panelId);
    if (panel) panel.classList.add('active');
  });
});

/* ── COPY CODE BUTTONS ──────────────────────────────────────── */
document.querySelectorAll('.code-copy').forEach(btn => {
  btn.addEventListener('click', () => {
    const block = btn.closest('.code-wrap')?.querySelector('pre');
    if (!block) return;
    
    const text = block.innerText || block.textContent;
    navigator.clipboard.writeText(text).then(() => {
      const original = btn.innerHTML;
      btn.innerHTML = '✓ Copiado';
      btn.classList.add('copied');
      setTimeout(() => {
        btn.innerHTML = original;
        btn.classList.remove('copied');
      }, 2000);
    });
  });
});

/* ── ACTIVE NAV LINK HIGHLIGHT ──────────────────────────────── */
(function highlightCurrentPage() {
  const currentPage = location.pathname.split('/').pop().replace('.html', '') || 'home';
  document.querySelectorAll('[data-page]').forEach(el => {
    if (el.dataset.page === currentPage) {
      el.classList.add('active');
    }
  });
})();

/* ── ANIMATED COUNTERS (para stats da home) ─────────────────── */
function initCounters() {
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        animateCounter(entry.target);
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.5 });
  
  document.querySelectorAll('[data-counter]').forEach(el => {
    observer.observe(el);
  });
}

function animateCounter(el) {
  const target = parseFloat(el.dataset.counter);
  const suffix = el.dataset.suffix || '';
  const duration = 1500;
  const start = performance.now();
  
  const update = (now) => {
    const progress = Math.min((now - start) / duration, 1);
    const ease = 1 - Math.pow(1 - progress, 3);
    const val = target * ease;
    
    el.textContent = (Number.isInteger(target) 
      ? Math.floor(val) 
      : val.toFixed(1)) + suffix;
    
    if (progress < 1) requestAnimationFrame(update);
  };
  
  requestAnimationFrame(update);
}

// Inicializa contadores quando o DOM carrega
document.addEventListener('DOMContentLoaded', initCounters);

/* ── TOC SIDEBAR ACTIVE LINK ────────────────────────────────── */
function initTOC() {
  const tocLinks = document.querySelectorAll('.toc a[href^="#"]');
  if (!tocLinks.length) return;
  
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        tocLinks.forEach(a => a.classList.remove('active'));
        const link = document.querySelector(`.toc a[href="#${entry.target.id}"]`);
        if (link) link.classList.add('active');
      }
    });
  }, { rootMargin: '-20% 0px -70% 0px', threshold: 0 });
  
  tocLinks.forEach(a => {
    const id = a.getAttribute('href').slice(1);
    const el = document.getElementById(id);
    if (el) observer.observe(el);
  });
}

document.addEventListener('DOMContentLoaded', initTOC);