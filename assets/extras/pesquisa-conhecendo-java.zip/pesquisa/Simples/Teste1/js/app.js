/* ================================================================
CONHECENDO JAVA — app.js (MPA version - sem router)
================================================================ */

/* ── Topbar scroll ── */
window.addEventListener('scroll', () => {
  document.getElementById('topbar')?.classList.toggle('scrolled', window.scrollY > 20);
  document.getElementById('scroll-top')?.classList.toggle('show', window.scrollY > 300);
});

/* ── Mobile menu toggle ── */
function toggleMenu() {
  document.getElementById('mobile-nav')?.classList.toggle('open');
}

/* ── Scroll to top ── */
document.getElementById('scroll-top')?.addEventListener('click', () => {
  window.scrollTo({ top: 0, behavior: 'smooth' });
});

/* ── Mobile dropdown toggles ── */
document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('.mobile-dropdown-toggle').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      btn.parentElement.classList.toggle('open');
    });
  });
});

/* ================================================================
COMPONENT INITIALIZERS
================================================================ */
function initComponents() {
  initAccordions();
  initTabs();
  initProgressBars();
  initCopyButtons();
  initCounters();
  initTOC();
}

function initAccordions() {
  document.querySelectorAll('.acc-head').forEach(head => {
    head.removeEventListener('click', accHandler);
    head.addEventListener('click', accHandler);
  });
}

function accHandler() {
  this.parentElement.classList.toggle('open');
}

function initTabs() {
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.removeEventListener('click', tabHandler);
    btn.addEventListener('click', tabHandler);
  });
}

function tabHandler() {
  const panelId = this.dataset.panel;
  const container = this.closest('.tabs');
  if (!container || !panelId) return;
  container.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
  container.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
  this.classList.add('active');
  const panel = container.querySelector('#' + panelId);
  if (panel) panel.classList.add('active');
}

function initProgressBars() {
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const bar = entry.target;
        const width = bar.dataset.width || '0';
        bar.style.width = width + '%';
        observer.unobserve(bar);
      }
    });
  }, { threshold: .3 });
  document.querySelectorAll('.progress-fill[data-width]').forEach(bar => {
    bar.style.width = '0';
    observer.observe(bar);
  });
}

function initCopyButtons() {
  document.querySelectorAll('.code-copy').forEach(btn => {
    btn.removeEventListener('click', copyHandler);
    btn.addEventListener('click', copyHandler);
  });
}

function copyHandler() {
  const block = this.closest('.code-wrap')?.querySelector('pre.code-block');
  if (!block) return;
  const text = block.innerText || block.textContent;
  navigator.clipboard.writeText(text).then(() => {
    const orig = this.innerHTML;
    this.innerHTML = '✓ Copiado';
    this.classList.add('copied');
    setTimeout(() => {
      this.innerHTML = orig;
      this.classList.remove('copied');
    }, 2000);
  });
}

function initCounters() {
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        animateCounter(entry.target);
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: .5 });
  document.querySelectorAll('[data-counter]').forEach(el => observer.observe(el));
}

function animateCounter(el) {
  const target = parseFloat(el.dataset.counter);
  const suffix = el.dataset.suffix || '';
  const duration = 1500;
  const start = performance.now();
  const update = (now) => {
    const progress = Math.min((now - start) / duration, 1);
    const ease = 1 - Math.pow(1 - progress, 3);
    const val = target * ease;
    el.textContent = (Number.isInteger(target) ? Math.floor(val) : val.toFixed(1)) + suffix;
    if (progress < 1) requestAnimationFrame(update);
  };
  requestAnimationFrame(update);
}

function initTOC() {
  const tocLinks = document.querySelectorAll('.toc a[href^="#"]');
  if (!tocLinks.length) return;
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        tocLinks.forEach(a => a.classList.remove('active'));
        const link = document.querySelector(`.toc a[href="#${entry.target.id}"]`);
        if (link) link.classList.add('active');
      }
    });
  }, { rootMargin: '-20% 0px -70% 0px', threshold: 0 });
  tocLinks.forEach(a => {
    const id = a.getAttribute('href').slice(1);
    const el = document.getElementById(id);
    if (el) observer.observe(el);
  });
}

/* ── PWA Install Prompt ── */
let deferredPrompt = null;
window.addEventListener('beforeinstallprompt', (e) => {
  e.preventDefault();
  deferredPrompt = e;
  const banner = document.getElementById('pwa-banner');
  if (banner && !localStorage.getItem('pwa-dismissed')) {
    banner.classList.add('show');
  }
});

document.getElementById('pwa-install-btn')?.addEventListener('click', async () => {
  if (!deferredPrompt) return;
  deferredPrompt.prompt();
  const { outcome } = await deferredPrompt.userChoice;
  if (outcome === 'accepted') {
    document.getElementById('pwa-banner')?.classList.remove('show');
  }
  deferredPrompt = null;
});

document.getElementById('pwa-dismiss-btn')?.addEventListener('click', () => {
  document.getElementById('pwa-banner')?.classList.remove('show');
  localStorage.setItem('pwa-dismissed', '1');
});

/* ── Service Worker ── */
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js')
      .then(reg => console.log('[SW] Registered:', reg.scope))
      .catch(err => console.warn('[SW] Failed:', err));
  });
}