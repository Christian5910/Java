/* ============================================================
   SERVICE WORKER — Conhecendo Java PWA
   ============================================================ */
const CACHE_NAME    = 'conhecendo-java-v2';
const STATIC_ASSETS = [
  '/',
  '/index.html',
  '/css/main.css',
  '/css/syntax.css',
  '/css/responsive.css',
  '/js/app.js',
  '/js/router.js',
  '/js/runner.js',
  '/js/syntax-highlight.js',
  '/pages/home.html',
  '/pages/historia.html',
  '/pages/sintaxe.html',
  '/pages/estrutura.html',
  '/pages/poo.html',
  '/pages/fundamentos.html',
  '/pages/conexoes.html',
  '/pages/recursos.html',
  '/pages/certificacoes.html',
  '/pages/download.html',
  '/manifest.json',
  'https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500;700&family=Bebas+Neue&display=swap',
  'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css'
];

/* ── Install ── */
self.addEventListener('install', e => {
  e.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => cache.addAll(STATIC_ASSETS))
      .then(() => self.skipWaiting())
  );
});

/* ── Activate ── */
self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

/* ── Fetch (Stale-While-Revalidate) ── */
self.addEventListener('fetch', e => {
  if (e.request.method !== 'GET') return;
  if (e.request.url.includes('/api/') || e.request.url.includes('anthropic.com')) return;

  e.respondWith(
    caches.match(e.request).then(cached => {
      const network = fetch(e.request).then(res => {
        if (res && res.status === 200) {
          const clone = res.clone();
          caches.open(CACHE_NAME).then(c => c.put(e.request, clone));
        }
        return res;
      }).catch(() => null);
      return cached || network;
    })
  );
});
