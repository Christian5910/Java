/* ================================================================
   CONHECENDO JAVA — app.js
   Main application logic, component initialization, utilities
   ================================================================ */

/* ── Topbar scroll ── */
window.addEventListener('scroll', () => {
  document.getElementById('topbar')
    .classList.toggle('scrolled', window.scrollY > 20);
  document.getElementById('scroll-top')
    .classList.toggle('show', window.scrollY > 300);
});

/* ── Mobile menu toggle ── */
function toggleMenu() {
  document.getElementById('mobile-nav').classList.toggle('open');
}

/* ── Scroll to top ── */
document.getElementById('scroll-top')?.addEventListener('click', () => {
  window.scrollTo({ top: 0, behavior: 'smooth' });
});

/* ================================================================
   COMPONENT INITIALIZERS (called after each page load)
   ================================================================ */
function initComponents() {
  initAccordions();
  initTabs();
  initProgressBars();
  initCopyButtons();
  initCounters();
}

/* ── Accordions ── */
function initAccordions() {
  document.querySelectorAll('.acc-head').forEach(head => {
    head.removeEventListener('click', accHandler);
    head.addEventListener('click', accHandler);
  });
}
function accHandler() {
  const item = this.parentElement;
  item.classList.toggle('open');
}

/* ── Tabs ── */
function initTabs() {
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.removeEventListener('click', tabHandler);
    btn.addEventListener('click', tabHandler);
  });
}
function tabHandler() {
  const panelId = this.dataset.panel;
  const container = this.closest('.tabs');
  if (!container || !panelId) return;

  container.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
  container.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
  this.classList.add('active');
  const panel = container.querySelector('#' + panelId);
  if (panel) panel.classList.add('active');
}

/* ── Progress bar animation (IntersectionObserver) ── */
function initProgressBars() {
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const bar = entry.target;
        const width = bar.dataset.width || '0';
        bar.style.width = width + '%';
        observer.unobserve(bar);
      }
    });
  }, { threshold: .3 });

  document.querySelectorAll('.progress-fill[data-width]').forEach(bar => {
    bar.style.width = '0';
    observer.observe(bar);
  });
}

/* ── Copy code buttons ── */
function initCopyButtons() {
  document.querySelectorAll('.code-copy').forEach(btn => {
    btn.removeEventListener('click', copyHandler);
    btn.addEventListener('click', copyHandler);
  });
}
function copyHandler() {
  const block = this.closest('.code-wrap')?.querySelector('pre.code-block');
  if (!block) return;
  const text = block.innerText || block.textContent;
  navigator.clipboard.writeText(text).then(() => {
    const orig = this.innerHTML;
    this.innerHTML = '✓ Copiado'; this.classList.add('copied');
    setTimeout(() => { this.innerHTML = orig; this.classList.remove('copied'); }, 2000);
  });
}

/* ── Animated counters ── */
function initCounters() {
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        animateCounter(entry.target);
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: .5 });

  document.querySelectorAll('[data-counter]').forEach(el => observer.observe(el));
}
function animateCounter(el) {
  const target = parseFloat(el.dataset.counter);
  const suffix = el.dataset.suffix || '';
  const duration = 1500;
  const start = performance.now();
  const update = (now) => {
    const progress = Math.min((now - start) / duration, 1);
    const ease = 1 - Math.pow(1 - progress, 3);
    const val = target * ease;
    el.textContent = (Number.isInteger(target) ? Math.floor(val) : val.toFixed(1)) + suffix;
    if (progress < 1) requestAnimationFrame(update);
  };
  requestAnimationFrame(update);
}

/* ================================================================
   TOC Active Link Observer
   ================================================================ */
function initTOC() {
  const tocLinks = document.querySelectorAll('.toc a[href^="#"]');
  if (!tocLinks.length) return;

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        tocLinks.forEach(a => a.classList.remove('active'));
        const link = document.querySelector(`.toc a[href="#${entry.target.id}"]`);
        if (link) link.classList.add('active');
      }
    });
  }, { rootMargin: '-20% 0px -70% 0px', threshold: 0 });

  tocLinks.forEach(a => {
    const id = a.getAttribute('href').slice(1);
    const el = document.getElementById(id);
    if (el) observer.observe(el);
  });
}

/* ================================================================
   UTILITIES
   ================================================================ */
/* Tab helper for external use */
function switchTab(btn, panelId) {
  btn.dataset.panel = panelId;
  tabHandler.call(btn);
}

/* Format number */
function fmt(n) { return new Intl.NumberFormat('pt-BR').format(n); }

/* Debounce */
function debounce(fn, ms) {
  let timer;
  return (...args) => { clearTimeout(timer); timer = setTimeout(() => fn(...args), ms); };
}

/* ================================================================
   PWA INSTALL PROMPT
   ================================================================ */
let deferredPrompt = null;
window.addEventListener('beforeinstallprompt', (e) => {
  e.preventDefault();
  deferredPrompt = e;
  const banner = document.getElementById('pwa-banner');
  if (banner && !localStorage.getItem('pwa-dismissed')) {
    banner.classList.add('show');
  }
});

document.getElementById('pwa-install-btn')?.addEventListener('click', async () => {
  if (!deferredPrompt) return;
  deferredPrompt.prompt();
  const { outcome } = await deferredPrompt.userChoice;
  if (outcome === 'accepted') {
    document.getElementById('pwa-banner')?.classList.remove('show');
  }
  deferredPrompt = null;
});

document.getElementById('pwa-dismiss-btn')?.addEventListener('click', () => {
  document.getElementById('pwa-banner')?.classList.remove('show');
  localStorage.setItem('pwa-dismissed', '1');
});

/* ================================================================
   SERVICE WORKER REGISTRATION
   ================================================================ */
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js')
      .then(reg => console.log('[SW] Registered:', reg.scope))
      .catch(err => console.warn('[SW] Failed:', err));
  });
}

/* ================================================================
   TOPBAR SEARCH (quick filter)
   ================================================================ */
function initSearch() {
  const input = document.getElementById('nav-search');
  if (!input) return;
  input.addEventListener('input', debounce((e) => {
    const q = e.target.value.toLowerCase();
    if (q.length < 2) return;
    const results = SEARCH_INDEX.filter(item =>
      item.title.toLowerCase().includes(q) ||
      item.keywords.some(k => k.includes(q))
    );
    showSearchResults(results);
  }, 300));
}

const SEARCH_INDEX = [
  { title: 'História do Java', page: 'historia', keywords: ['green project','gosling','oracle','sun','1995'] },
  { title: 'Sintaxe — Variáveis', page: 'sintaxe', keywords: ['int','string','boolean','var','tipo'] },
  { title: 'Sintaxe — Loops', page: 'sintaxe', keywords: ['for','while','do','loop','repetição'] },
  { title: 'JVM / JDK / JRE', page: 'estrutura', keywords: ['jvm','jdk','jre','bytecode','compilar'] },
  { title: 'Garbage Collector', page: 'estrutura', keywords: ['gc','g1','zgc','memória','heap'] },
  { title: 'POO — Encapsulamento', page: 'poo', keywords: ['encapsulamento','getter','setter','private'] },
  { title: 'POO — Herança', page: 'poo', keywords: ['herança','extends','super','subclasse'] },
  { title: 'POO — Polimorfismo', page: 'poo', keywords: ['polimorfismo','override','overload'] },
  { title: 'POO — Abstração', page: 'poo', keywords: ['abstração','abstract','interface'] },
  { title: 'Collections', page: 'fundamentos', keywords: ['list','map','set','arraylist','hashmap'] },
  { title: 'Streams & Lambda', page: 'fundamentos', keywords: ['stream','lambda','filter','map','reduce'] },
  { title: 'Spring Boot', page: 'conexoes', keywords: ['spring','boot','rest','api','framework'] },
  { title: 'Download Java', page: 'download', keywords: ['download','instalar','jdk','jre','openJDK'] },
];

function showSearchResults(results) {
  /* Simple toast with results — can be expanded */
  console.log('Search results:', results);
}
