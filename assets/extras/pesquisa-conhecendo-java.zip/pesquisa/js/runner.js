/* ================================================================
   CONHECENDO JAVA — runner.js
   Java Playground powered by Claude API
   ================================================================ */

const RUNNER_SYSTEM = `Você é um executor de código Java preciso e educativo.
Quando o usuário enviar código Java, simule sua execução da seguinte forma:

1. Analise o código em busca de erros de compilação (sintaxe, tipos, etc.).
2. Se houver erros, responda APENAS com:
   ERRO DE COMPILAÇÃO:
   [mensagem de erro similar ao javac — arquivo, linha, descrição]
   
3. Se o código compilar corretamente, simule a saída do programa. Responda com:
   > Compilando MeuPrograma.java...
   > Compilação bem-sucedida.
   > Executando...
   
   [saída exata que o programa produziria, incluindo println, print, etc.]
   
   > Programa finalizado em X ms.

4. Se o código tiver problemas lógicos (divisão por zero, NPE, etc.), mostre o stack trace realista.
5. Seja preciso: calcule expressões matemáticas, itere loops corretamente, etc.
6. Nunca explique o código — apenas execute e mostre a saída.
7. Responda SOMENTE com a saída de compilação/execução, sem texto adicional.`;

/* ── Run button handler ── */
async function runJavaCode() {
  const btn    = document.getElementById('run-btn');
  const input  = document.getElementById('java-input');
  const output = document.getElementById('output-box');
  const status = document.getElementById('runner-status');

  if (!btn || !input || !output) return;

  const code = input.value.trim();
  if (!code) {
    output.innerHTML = '<span class="out-info">// Digite algum código Java para executar.</span>';
    return;
  }

  btn.disabled = true;
  btn.innerHTML = '<i class="fa fa-spinner fa-spin"></i> Compilando...';
  if (status) status.textContent = 'Processando...';
  output.innerHTML = '<span class="out-info">Compilando e executando...</span>';

  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 1000,
        system: RUNNER_SYSTEM,
        messages: [{ role: 'user', content: code }]
      })
    });

    const data = await response.json();
    const result = data.content?.[0]?.text || 'Sem resposta do executor.';

    /* Color the output */
    output.innerHTML = formatOutput(result);

    if (status) {
      const isError = result.toLowerCase().includes('erro') || result.toLowerCase().includes('exception');
      status.textContent = isError ? '⚠️ Erros encontrados' : '✅ Executado com sucesso';
      status.style.color = isError ? 'var(--j-red)' : 'var(--j-green)';
    }

  } catch (err) {
    output.innerHTML = `<span class="out-err">Erro ao conectar com o executor.\n${err.message}</span>`;
    if (status) status.textContent = '❌ Falha na conexão';
  } finally {
    btn.disabled = false;
    btn.innerHTML = '<i class="fa fa-play"></i> Executar';
  }
}

/* ── Format output with colors ── */
function formatOutput(text) {
  return text
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .split('\n').map(line => {
      if (line.startsWith('ERRO') || line.includes('Exception') || line.includes('error:')) {
        return `<span class="out-err">${line}</span>`;
      }
      if (line.startsWith('> Compilando') || line.startsWith('> Executando') || line.startsWith('> Compilação')) {
        return `<span class="out-info">${line}</span>`;
      }
      if (line.startsWith('> Programa finalizado')) {
        return `<span style="color:var(--j-yellow)">${line}</span>`;
      }
      return line;
    }).join('\n');
}

/* ── Clear ── */
function clearRunner() {
  const output = document.getElementById('output-box');
  const status = document.getElementById('runner-status');
  if (output) output.innerHTML = '<span class="out-info">// Saída limpa. Execute um novo código.</span>';
  if (status) { status.textContent = ''; status.style.color = ''; }
}

/* ── Load example ── */
function loadExample(name) {
  const input = document.getElementById('java-input');
  if (!input) return;
  const ex = EXAMPLES[name];
  if (ex) input.value = ex;
}

/* ── Code examples ── */
const EXAMPLES = {
  hello: `public class OlaMundo {
    public static void main(String[] args) {
        System.out.println("Olá, Mundo! ☕");
        System.out.println("Java versão: " + System.getProperty("java.version"));
    }
}`,

  fibonacci: `public class Fibonacci {
    public static void main(String[] args) {
        int n = 15;
        System.out.println("Sequência de Fibonacci até " + n + " termos:");
        int a = 0, b = 1;
        for (int i = 0; i < n; i++) {
            System.out.print(a + (i < n-1 ? ", " : ""));
            int temp = a + b;
            a = b;
            b = temp;
        }
        System.out.println();
    }
}`,

  poo: `public class Animal {
    private String nome;
    private String som;
    
    public Animal(String nome, String som) {
        this.nome = nome;
        this.som  = som;
    }
    
    public void fazerSom() {
        System.out.println(nome + " diz: " + som);
    }
    
    public static void main(String[] args) {
        Animal[] animais = {
            new Animal("Cachorro", "Au au! 🐕"),
            new Animal("Gato",     "Miau! 🐈"),
            new Animal("Pato",     "Quack! 🦆")
        };
        
        System.out.println("=== Fazenda Java ===");
        for (Animal a : animais) {
            a.fazerSom();
        }
    }
}`,

  lambda: `import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class StreamsDemo {
    public static void main(String[] args) {
        List<Integer> numeros = Arrays.asList(1,2,3,4,5,6,7,8,9,10);
        
        // Pares ao quadrado
        List<Integer> resultado = numeros.stream()
            .filter(n -> n % 2 == 0)
            .map(n -> n * n)
            .collect(Collectors.toList());
        
        System.out.println("Pares ao quadrado: " + resultado);
        
        int soma = numeros.stream()
            .reduce(0, Integer::sum);
        System.out.println("Soma de 1 a 10: " + soma);
        
        long pares = numeros.stream()
            .filter(n -> n % 2 == 0)
            .count();
        System.out.println("Quantidade de pares: " + pares);
    }
}`,

  record: `// Records — Java 16+
public class RecordsDemo {
    record Ponto(double x, double y) {
        // Método customizado no record
        double distanciaOrigem() {
            return Math.sqrt(x * x + y * y);
        }
    }
    
    record Pessoa(String nome, int idade, String email) {}
    
    public static void main(String[] args) {
        var p1 = new Ponto(3.0, 4.0);
        var p2 = new Ponto(0.0, 0.0);
        
        System.out.println("P1: " + p1);
        System.out.printf("Distância da origem: %.1f%n", p1.distanciaOrigem());
        System.out.println("P1 == P2? " + p1.equals(p2));
        
        var pessoa = new Pessoa("Ana", 28, "ana@java.com");
        System.out.println("\\nPessoa: " + pessoa);
        System.out.println("Nome: " + pessoa.nome());
    }
}`,

  collections: `import java.util.*;
import java.util.stream.*;

public class CollectionsDemo {
    public static void main(String[] args) {
        // ArrayList
        List<String> linguagens = new ArrayList<>(
            Arrays.asList("Java", "Kotlin", "Scala", "Groovy")
        );
        linguagens.add("Clojure");
        linguagens.sort(String::compareTo);
        System.out.println("Linguagens JVM: " + linguagens);
        
        // HashMap
        Map<String, Integer> versoes = new LinkedHashMap<>();
        versoes.put("Java 8 LTS",  2014);
        versoes.put("Java 11 LTS", 2018);
        versoes.put("Java 17 LTS", 2021);
        versoes.put("Java 21 LTS", 2023);
        versoes.put("Java 25 LTS", 2025);
        
        System.out.println("\\nVersions LTS:");
        versoes.forEach((v, y) -> System.out.printf("  %-12s → %d%n", v, y));
        
        // Set
        Set<String> unicos = new TreeSet<>(linguagens);
        unicos.add("Java"); // duplicata ignorada
        System.out.println("\\nSet ordenado: " + unicos);
    }
}`
};

/* ── Tab handling within runner page (keyboard shortcut) ── */
document.addEventListener('keydown', (e) => {
  const input = document.getElementById('java-input');
  if (document.activeElement === input && e.key === 'Tab') {
    e.preventDefault();
    const start = input.selectionStart;
    const end   = input.selectionEnd;
    input.value = input.value.substring(0, start) + '  ' + input.value.substring(end);
    input.selectionStart = input.selectionEnd = start + 2;
  }
  /* Ctrl+Enter = run */
  if (e.ctrlKey && e.key === 'Enter') {
    runJavaCode();
  }
});
