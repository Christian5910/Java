package br.estudo.catalogo;
import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.junit.jupiter.api.Assertions.*;
@SpringBootTest @AutoConfigureMockMvc
class CatalogoTest {
 @Autowired MockMvc mvc; @Autowired ProdutoRepository repositorio;
 @BeforeEach void limpar(){repositorio.deleteAll();}
 private Produto produto(){return repositorio.saveAndFlush(new Produto("KIT01",5));}
 @Test void listaPublica() throws Exception {mvc.perform(get("/api/produtos")).andExpect(status().isOk()).andExpect(jsonPath("$.itens").isEmpty());}
 @Test void criarValido() throws Exception {mvc.perform(post("/api/produtos").with(user("a").roles("ADMIN")).with(csrf()).contentType("application/json").content("{\"codigo\":\"KIT01\",\"quantidade\":5}")).andExpect(status().isCreated()).andExpect(header().exists("Location")).andExpect(jsonPath("$.quantidade").value(5));assertEquals(1,repositorio.count());}
 @Test void semCredencial() throws Exception {mvc.perform(post("/api/produtos").with(csrf()).contentType("application/json").content("{\"codigo\":\"K\",\"quantidade\":1}")).andExpect(status().isUnauthorized());}
 @Test void basicReal() throws Exception {mvc.perform(post("/api/produtos").with(httpBasic("estudante","senha-local-de-estudo")).with(csrf()).contentType("application/json").content("{\"codigo\":\"K\",\"quantidade\":1}")).andExpect(status().isCreated());}
 @Test void basicInvalido() throws Exception {mvc.perform(get("/api/produtos").with(httpBasic("estudante","incorreta"))).andExpect(status().isUnauthorized());}
 @Test void papelInsuficiente() throws Exception {mvc.perform(post("/api/produtos").with(user("a").roles("LEITOR")).with(csrf()).contentType("application/json").content("{}")).andExpect(status().isForbidden());}
 @Test void semCsrf() throws Exception {mvc.perform(post("/api/produtos").with(user("a").roles("ADMIN")).contentType("application/json").content("{}")).andExpect(status().isForbidden());}
 @Test void negativo() throws Exception {for(String quantidade : new String[]{"-1","1.5","null"}){mvc.perform(post("/api/produtos").with(user("a").roles("ADMIN")).with(csrf()).contentType("application/json").content("{\"codigo\":\"K\",\"quantidade\":"+quantidade+"}")).andExpect(status().isBadRequest());}assertEquals(0,repositorio.count());}
 @Test void ausente() throws Exception {mvc.perform(get("/api/produtos/999999")).andExpect(status().isNotFound());}
 @Test void retirar() throws Exception {var p=produto();mvc.perform(post("/api/produtos/"+p.getId()+"/retiradas").with(user("a").roles("ADMIN")).with(csrf()).contentType("application/json").content("{\"quantidade\":2,\"versao\":"+p.getVersao()+"}")).andExpect(status().isOk()).andExpect(jsonPath("$.quantidade").value(3));assertEquals(3,repositorio.findById(p.getId()).orElseThrow().getQuantidade());}
 @Test void saldoRecusado() throws Exception {var p=produto();mvc.perform(post("/api/produtos/"+p.getId()+"/retiradas").with(user("a").roles("ADMIN")).with(csrf()).contentType("application/json").content("{\"quantidade\":6,\"versao\":"+p.getVersao()+"}")).andExpect(status().isConflict());assertEquals(5,repositorio.findById(p.getId()).orElseThrow().getQuantidade());}
 @Test void versaoDesatualizada() throws Exception {var p=produto();mvc.perform(post("/api/produtos/"+p.getId()+"/retiradas").with(user("a").roles("ADMIN")).with(csrf()).contentType("application/json").content("{\"quantidade\":1,\"versao\":999}")).andExpect(status().isConflict());assertEquals(5,repositorio.findById(p.getId()).orElseThrow().getQuantidade());}
 @Test void duplicacao() throws Exception {produto();mvc.perform(post("/api/produtos").with(user("a").roles("ADMIN")).with(csrf()).contentType("application/json").content("{\"codigo\":\"KIT01\",\"quantidade\":1}")).andExpect(status().isConflict());assertEquals(1,repositorio.count());}
 @Test void limitePagina() throws Exception {mvc.perform(get("/api/produtos?tamanho=101")).andExpect(status().isBadRequest());}
 @Test void jsonQuebrado() throws Exception {mvc.perform(post("/api/produtos").with(user("a").roles("ADMIN")).with(csrf()).contentType("application/json").content("{")).andExpect(status().isBadRequest());}
 @Test void tokenDisponivel() throws Exception {mvc.perform(get("/api/csrf")).andExpect(status().isOk()).andExpect(jsonPath("$.token").isNotEmpty()).andExpect(jsonPath("$.headerName").value("X-CSRF-TOKEN"));}
 @Test void saudeRestrita() throws Exception {mvc.perform(get("/actuator/health")).andExpect(status().isOk()).andExpect(jsonPath("$.status").value("UP")).andExpect(jsonPath("$.components").doesNotExist());}
}
