package br.estudo.catalogo;
import java.util.Map;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.*;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.userdetails.*;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.csrf.CsrfToken;
import org.springframework.web.bind.annotation.*;
@Configuration
public class Seguranca {
 @Bean UserDetailsService usuarios(@Value("${lab.password}") String senha){
  return new InMemoryUserDetailsManager(User.withUsername("estudante").password(new BCryptPasswordEncoder().encode(senha)).roles("ADMIN").build());
 }
 @Bean BCryptPasswordEncoder passwordEncoder(){return new BCryptPasswordEncoder();}
 @Bean SecurityFilterChain filtros(HttpSecurity http) throws Exception {
  return http.authorizeHttpRequests(regras->regras
   .requestMatchers("/api/csrf","/actuator/health").permitAll()
   .requestMatchers(HttpMethod.GET,"/api/produtos","/api/produtos/**").permitAll()
   .requestMatchers(HttpMethod.POST,"/api/produtos","/api/produtos/**").hasRole("ADMIN")
   .anyRequest().denyAll()).httpBasic(Customizer.withDefaults()).build();
 }
 @RestController static class CsrfController {
  @GetMapping("/api/csrf") Map<String,String> token(CsrfToken token){return Map.of("token",token.getToken(),"headerName",token.getHeaderName());}
 }
}
