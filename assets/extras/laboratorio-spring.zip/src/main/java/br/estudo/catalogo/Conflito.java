package br.estudo.catalogo;
public class Conflito extends RuntimeException { public Conflito(String mensagem){super(mensagem);} }
