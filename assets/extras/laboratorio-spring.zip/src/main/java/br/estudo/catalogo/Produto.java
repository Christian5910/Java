package br.estudo.catalogo;
import jakarta.persistence.*;
@Entity
@Table(uniqueConstraints=@UniqueConstraint(columnNames="codigo"))
public class Produto {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
 @Version private Long versao;
 @Column(nullable=false,length=30) private String codigo;
 @Column(nullable=false) private int quantidade;
 protected Produto() {}
 Produto(String codigo,int quantidade) {
  if (codigo==null || !codigo.matches("[A-Z0-9_-]{1,30}") || quantidade<0) throw new IllegalArgumentException("Dados inválidos");
  this.codigo=codigo;this.quantidade=quantidade;
 }
 void retirar(int valor,long esperada) {
  if (valor<=0) throw new IllegalArgumentException("Quantidade deve ser positiva");
  if (versao==null || versao!=esperada) throw new Conflito("Versão desatualizada");
  if (valor>quantidade) throw new Conflito("Saldo insuficiente");
  quantidade-=valor;
 }
 public Long getId(){return id;} public Long getVersao(){return versao;}
 public String getCodigo(){return codigo;} public int getQuantidade(){return quantidade;}
}
