package br.estudo.catalogo;
import jakarta.validation.constraints.*;
public final class Contratos {
 private Contratos(){}
 public record Criar(@NotBlank @Pattern(regexp="[A-Z0-9_-]{1,30}") String codigo,@NotNull @PositiveOrZero Integer quantidade){}
 public record Retirar(@NotNull @Positive Integer quantidade,@NotNull @PositiveOrZero Long versao){}
 public record Resposta(Long id,String codigo,int quantidade,Long versao){
  static Resposta de(Produto p){return new Resposta(p.getId(),p.getCodigo(),p.getQuantidade(),p.getVersao());}
 }
}
