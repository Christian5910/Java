package br.estudo.catalogo;
import java.util.NoSuchElementException;
import org.springframework.data.domain.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
@Service
public class ProdutoService {
 private final ProdutoRepository repositorio;
 public ProdutoService(ProdutoRepository repositorio){this.repositorio=repositorio;}
 @Transactional public Contratos.Resposta criar(Contratos.Criar dados){
  return Contratos.Resposta.de(repositorio.saveAndFlush(new Produto(dados.codigo(),dados.quantidade())));
 }
 @Transactional(readOnly=true) public Contratos.Resposta buscar(long id){return Contratos.Resposta.de(encontrar(id));}
 @Transactional(readOnly=true) public Page<Contratos.Resposta> listar(int pagina,int tamanho){
  return repositorio.findAll(PageRequest.of(pagina,tamanho,Sort.by("id").ascending())).map(Contratos.Resposta::de);
 }
 @Transactional public Contratos.Resposta retirar(long id,Contratos.Retirar dados){
  Produto produto=encontrar(id);produto.retirar(dados.quantidade(),dados.versao());repositorio.flush();
  return Contratos.Resposta.de(produto);
 }
 private Produto encontrar(long id){return repositorio.findById(id).orElseThrow(()->new NoSuchElementException("Produto não encontrado"));}
}
