package br.estudo.catalogo;
import java.net.URI;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
@RestController
@RequestMapping("/api/produtos")
public class ProdutoController {
 private final ProdutoService servico;
 public ProdutoController(ProdutoService servico){this.servico=servico;}
 @PostMapping public ResponseEntity<Contratos.Resposta> criar(@Valid @RequestBody Contratos.Criar dados){
  var resposta=servico.criar(dados);return ResponseEntity.created(URI.create("/api/produtos/"+resposta.id())).body(resposta);
 }
 @GetMapping("/{id}") public Contratos.Resposta buscar(@PathVariable long id){return servico.buscar(id);}
 public record Pagina(java.util.List<Contratos.Resposta> itens,int pagina,int tamanho,long total){}
 @GetMapping public Pagina listar(@RequestParam(defaultValue="0") int pagina,@RequestParam(defaultValue="20") int tamanho){
  if(pagina<0 || tamanho<1 || tamanho>100) throw new IllegalArgumentException("Página ou tamanho inválido");
  var dados=servico.listar(pagina,tamanho);return new Pagina(dados.getContent(),pagina,tamanho,dados.getTotalElements());
 }
 @PostMapping("/{id}/retiradas") public Contratos.Resposta retirar(@PathVariable long id,@Valid @RequestBody Contratos.Retirar dados){return servico.retirar(id,dados);}
}
