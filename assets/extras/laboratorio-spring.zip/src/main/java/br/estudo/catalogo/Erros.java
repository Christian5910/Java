package br.estudo.catalogo;
import java.util.NoSuchElementException;
import org.springframework.dao.*;
import org.springframework.http.*;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
@RestControllerAdvice
public class Erros {
 @ExceptionHandler(NoSuchElementException.class) ProblemDetail ausente(NoSuchElementException e){return problema(404,"Produto não encontrado");}
 @ExceptionHandler({Conflito.class,DataIntegrityViolationException.class,OptimisticLockingFailureException.class})
 ProblemDetail conflito(Exception e){return problema(409,"Operação em conflito com o estado atual");}
 @ExceptionHandler({IllegalArgumentException.class,MethodArgumentNotValidException.class,HttpMessageNotReadableException.class,MethodArgumentTypeMismatchException.class})
 ProblemDetail invalido(Exception e){return problema(400,"Confira os campos, os tipos e os limites informados");}
 private ProblemDetail problema(int status,String mensagem){return ProblemDetail.forStatusAndDetail(HttpStatusCode.valueOf(status),mensagem);}
}
