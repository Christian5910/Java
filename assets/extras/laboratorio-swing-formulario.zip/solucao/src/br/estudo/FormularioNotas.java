package br.estudo;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.KeyEvent;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class FormularioNotas extends JPanel {
    private static final String INICIAL = "Informe o nome e a nota para conferir a situação.";
    private static final String SEM_ERRO = " "; // mantém a altura da linha, para a tela não "pular"
    // Largura suficiente para a maior mensagem de erro e para o resultado com um nome de 60 caracteres:
    // a janela é dimensionada uma vez (pack) e textos maiores que o espaço seriam cortados.
    private static final int LARGURA_MINIMA = 640;

    private final JTextField campoNome = new JTextField(20);
    private final JTextField campoNota = new JTextField(8);
    private final JLabel erroNome = new JLabel(SEM_ERRO);
    private final JLabel erroNota = new JLabel(SEM_ERRO);
    private final JLabel resultado = new JLabel(INICIAL);
    private final JButton conferir = new JButton("Conferir");
    private final JButton limpar = new JButton("Limpar");

    public FormularioNotas() {
        super(new GridBagLayout());
        setBorder(BorderFactory.createEmptyBorder(16, 16, 16, 16));

        JLabel rotuloNome = new JLabel("Nome do aluno:");
        rotuloNome.setLabelFor(campoNome);
        JLabel rotuloNota = new JLabel("Nota (0 a 10):");
        rotuloNota.setLabelFor(campoNota);
        erroNome.getAccessibleContext().setAccessibleName("Erro do nome");
        erroNota.getAccessibleContext().setAccessibleName("Erro da nota");
        resultado.getAccessibleContext().setAccessibleName("Resultado da avaliação");
        // vermelho escuro sobre o fundo claro padrão: contraste acima de 5:1; a mensagem também é texto, não só cor
        erroNome.setForeground(new Color(0xB0, 0x00, 0x20));
        erroNota.setForeground(new Color(0xB0, 0x00, 0x20));
        conferir.setMnemonic(KeyEvent.VK_C);
        limpar.setMnemonic(KeyEvent.VK_L);
        conferir.addActionListener(evento -> conferir());
        limpar.addActionListener(evento -> limpar());

        JPanel botoes = new JPanel(new FlowLayout(FlowLayout.LEADING, 0, 0));
        botoes.add(conferir);
        botoes.add(javax.swing.Box.createHorizontalStrut(8));
        botoes.add(limpar);

        linha(0, rotuloNome, campoNome);
        linha(1, null, erroNome);
        linha(2, rotuloNota, campoNota);
        linha(3, null, erroNota);
        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 0;
        c.gridy = 4;
        c.gridwidth = 2;
        c.weightx = 1;
        c.anchor = GridBagConstraints.LINE_START;
        c.insets = new Insets(8, 0, 12, 0);
        add(botoes, c);
        c.gridy = 5;
        c.insets = new Insets(0, 0, 0, 0);
        add(resultado, c);
        setPreferredSize(new java.awt.Dimension(Math.max(getPreferredSize().width, LARGURA_MINIMA), getPreferredSize().height));
    }

    private void linha(int y, JComponent esquerda, JComponent direita) {
        GridBagConstraints c = new GridBagConstraints();
        c.gridy = y;
        c.anchor = GridBagConstraints.LINE_START;
        if (esquerda != null) {
            c.gridx = 0;
            c.insets = new Insets(0, 0, 0, 8);
            add(esquerda, c);
        }
        c.gridx = 1;
        c.weightx = 1; // a coluna dos campos absorve o espaço extra, sem centralizar o formulário
        c.insets = new Insets(0, 0, 0, 0);
        add(direita, c);
    }

    private void conferir() {
        String problemaNome = null;
        String problemaNota = null;
        String nome = null;
        String situacao = null;
        try {
            nome = Nome.normalizar(campoNome.getText());
        } catch (IllegalArgumentException erro) {
            problemaNome = erro.getMessage();
        }
        try {
            situacao = Nota.avaliar(campoNota.getText());
        } catch (IllegalArgumentException erro) {
            problemaNota = erro.getMessage();
        }
        erroNome.setText(problemaNome == null ? SEM_ERRO : problemaNome);
        erroNota.setText(problemaNota == null ? SEM_ERRO : problemaNota);
        if (problemaNome != null || problemaNota != null) {
            resultado.setText("Corrija os campos indicados.");
            (problemaNome != null ? campoNome : campoNota).requestFocusInWindow();
            return;
        }
        resultado.setText(nome + ": " + situacao);
    }

    private void limpar() {
        campoNome.setText("");
        campoNota.setText("");
        erroNome.setText(SEM_ERRO);
        erroNota.setText(SEM_ERRO);
        resultado.setText(INICIAL);
        campoNome.requestFocusInWindow();
    }

    /** Botão acionado por Enter quando a janela está em foco. */
    public JButton botaoPadrao() {
        return conferir;
    }
}
