package br.estudo;

public final class Nome {
    private static final int MINIMO = 2;
    private static final int MAXIMO = 60;

    private Nome() {}

    /**
     * Valida e normaliza o nome digitado: remove espaços nas pontas e reduz qualquer sequência de espaços
     * (inclusive tabulações) a um único espaço. Verifica, nesta ordem: ausência, caracteres, início e tamanho.
     */
    public static String normalizar(String texto) {
        if (texto == null || texto.isBlank()) throw new IllegalArgumentException("Informe o nome.");
        String nome = texto.trim().replaceAll("\\s+", " ");
        for (int i = 0; i < nome.length(); i++) {
            char c = nome.charAt(i);
            if (!(Character.isLetter(c) || c == ' ' || c == '-' || c == '\'' || c == '’')) {
                throw new IllegalArgumentException("Use apenas letras, espaços, hífen e apóstrofo.");
            }
        }
        if (!Character.isLetter(nome.charAt(0))) throw new IllegalArgumentException("O nome deve começar com uma letra.");
        if (nome.length() < MINIMO || nome.length() > MAXIMO) throw new IllegalArgumentException("Use de 2 a 60 caracteres.");
        return nome;
    }
}
