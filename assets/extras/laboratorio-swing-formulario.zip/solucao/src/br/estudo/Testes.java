package br.estudo;

public class Testes {
    private static int total = 0;

    private static void conferir(boolean condicao, String cenario) {
        if (!condicao) throw new AssertionError(cenario);
        total++;
    }

    private static void nota(String texto, String situacao) {
        conferir(Nota.avaliar(texto).equals(situacao), "nota " + texto);
    }

    private static void notaRecusada(String texto) {
        try {
            Nota.avaliar(texto);
        } catch (IllegalArgumentException esperado) {
            total++;
            return;
        }
        throw new AssertionError("Aceitou a nota " + texto);
    }

    private static void nome(String texto, String esperado) {
        conferir(Nome.normalizar(texto).equals(esperado), "nome " + texto);
    }

    private static void nomeRecusado(String texto, String mensagem) {
        try {
            Nome.normalizar(texto);
        } catch (IllegalArgumentException esperado) {
            conferir(esperado.getMessage().equals(mensagem), "mensagem para o nome " + texto);
            return;
        }
        throw new AssertionError("Aceitou o nome " + texto);
    }

    public static void main(String[] args) {
        for (String valor : new String[] {"7", "10", "7,5"}) nota(valor, "Aprovado");
        for (String valor : new String[] {"0", "6.99"}) nota(valor, "Em recuperação");
        for (String valor : new String[] {null, "", "abc", "-1", "11", "NaN", "Infinity"}) notaRecusada(valor);

        nome("Ana", "Ana");
        nome("  Ana   Silva  ", "Ana Silva");
        nome("Ana\tSilva", "Ana Silva");
        nome("José", "José");
        nome("D'Ávila", "D'Ávila");
        nome("Ana-Maria", "Ana-Maria");
        nome("Li", "Li");
        nome("A".repeat(60), "A".repeat(60));
        for (String valor : new String[] {null, "", "   "}) nomeRecusado(valor, "Informe o nome.");
        for (String valor : new String[] {"Ana3", "Ana_", "Ana@"}) nomeRecusado(valor, "Use apenas letras, espaços, hífen e apóstrofo.");
        for (String valor : new String[] {"-Ana", "'Ana"}) nomeRecusado(valor, "O nome deve começar com uma letra.");
        for (String valor : new String[] {"A", "A".repeat(61)}) nomeRecusado(valor, "Use de 2 a 60 caracteres.");
        System.out.println(total + " verificações de domínio passaram.");
    }
}
