package br.estudo;

public final class Nota {
    private Nota() {}

    public static String avaliar(String texto) {
        if (texto == null || texto.isBlank()) throw new IllegalArgumentException("Informe a nota.");
        final double nota;
        try {
            nota = Double.parseDouble(texto.trim().replace(',', '.'));
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Use um número de 0 a 10.");
        }
        if (!Double.isFinite(nota) || nota < 0 || nota > 10) throw new IllegalArgumentException("Use um número de 0 a 10.");
        return nota >= 7 ? "Aprovado" : "Em recuperação";
    }
}
