package br.estudo;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.KeyEvent;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

/** Ponto de partida: o formulário do capítulo 16, em um painel que a janela (Main) apenas hospeda. */
public class FormularioNotas extends JPanel {
    private final JTextField campoNota = new JTextField(14);
    private final JLabel resultado = new JLabel("Informe a nota para conferir a situação.");
    private final JButton conferir = new JButton("Conferir");

    public FormularioNotas() {
        super(new BorderLayout(12, 12));
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        JLabel rotuloNota = new JLabel("Nota (0 a 10):");
        rotuloNota.setLabelFor(campoNota);
        resultado.getAccessibleContext().setAccessibleName("Resultado da avaliação");
        conferir.setMnemonic(KeyEvent.VK_C);
        conferir.addActionListener(evento -> {
            try {
                resultado.setText(Nota.avaliar(campoNota.getText()));
            } catch (IllegalArgumentException erro) {
                resultado.setText(erro.getMessage());
                campoNota.requestFocusInWindow();
            }
        });
        JPanel linha = new JPanel(new FlowLayout(FlowLayout.LEADING));
        linha.add(rotuloNota);
        linha.add(campoNota);
        linha.add(conferir);
        add(linha, BorderLayout.NORTH);
        add(resultado, BorderLayout.CENTER);
    }

    /** Botão acionado por Enter quando a janela está em foco. */
    public JButton botaoPadrao() {
        return conferir;
    }
}
