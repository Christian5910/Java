package br.estudo;

import java.awt.Component;
import java.awt.Container;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.atomic.AtomicBoolean;
import javax.accessibility.Accessible;
import javax.swing.AbstractButton;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

/**
 * Verifica o contrato do formulário SEM abrir janela: monta FormularioNotas, preenche os campos, aciona os
 * botões e lê os textos pelo modelo de componentes do Swing. Não é uma nota: cada linha diz o que foi
 * conferido. Foco e teclado em uma janela real não são verificáveis aqui e ficam na lista MANUAL.
 *
 * Uso:  java -cp out br.estudo.VerificarFormulario            (contrato das etapas 2 a 4)
 *       java -cp out br.estudo.VerificarFormulario consulta   (acrescenta o contrato do desafio D1)
 */
public class VerificarFormulario {
    static final String INICIAL = "Informe o nome e a nota para conferir a situação.";

    private interface Corpo {
        void executar() throws Exception;
    }

    private static final List<String> FALHAS = new ArrayList<>();
    private static final java.util.Set<String> CAUSAS = new java.util.HashSet<>();
    private static int passaram = 0;
    private static FormularioNotas form;
    private static List<Component> todos = new ArrayList<>();

    public static void main(String[] args) throws Exception {
        System.setProperty("java.awt.headless", "true");
        boolean consulta = args.length > 0 && args[0].equals("consulta");

        verificar("o formulário monta sem erro", () -> {
            form = naEdt(() -> {
                FormularioNotas novo = new FormularioNotas();
                // Sem janela não há "peer": o layout é calculado diretamente, de cima para baixo.
                novo.setSize(novo.getPreferredSize());
                dispor(novo);
                return novo;
            });
            coletar(form, todos);
        });
        verificar("campo do nome com nome acessível \"Nome do aluno\"", () -> campo("Nome do aluno"));
        verificar("campo da nota com nome acessível \"Nota (0 a 10)\"", () -> campo("Nota (0 a 10)"));
        verificar("botão Conferir com mnemônico C, e é o botão padrão", () -> {
            exigir(botao("Conferir").getMnemonic() == 'C', "o mnemônico de Conferir deve ser a tecla C");
            exigir(form.botaoPadrao() == botao("Conferir"), "botaoPadrao() deve devolver o botão Conferir");
        });
        verificar("botão Limpar com mnemônico L", () -> exigir(botao("Limpar").getMnemonic() == 'L', "o mnemônico de Limpar deve ser a tecla L"));
        verificar("mensagem de erro do nome fica entre o campo do nome e o da nota", () -> {
            int y = topo(rotulo("Erro do nome")), nome = topo(campo("Nome do aluno")), nota = topo(campo("Nota (0 a 10)"));
            exigir(y > nome && y < nota, "o rótulo \"Erro do nome\" deve ficar abaixo do campo do nome e acima do campo da nota");
        });
        verificar("mensagem de erro da nota fica abaixo do campo da nota", () ->
            exigir(topo(rotulo("Erro da nota")) > topo(campo("Nota (0 a 10)")), "o rótulo \"Erro da nota\" deve ficar abaixo do campo da nota"));
        verificar("ordem visual dos controles: nome, nota, Conferir, Limpar", () -> {
            List<Component> ordem = new ArrayList<>(List.of(campo("Nome do aluno"), campo("Nota (0 a 10)"), botao("Conferir"), botao("Limpar")));
            ordem.sort(Comparator.<Component>comparingInt(c -> topo(c) / 12).thenComparingInt(c -> esquerda(c)));
            exigir(ordem.get(0) == campo("Nome do aluno") && ordem.get(1) == campo("Nota (0 a 10)")
                && ordem.get(2) == botao("Conferir") && ordem.get(3) == botao("Limpar"),
                "a leitura de cima para baixo e da esquerda para a direita deve ser nome, nota, Conferir, Limpar");
        });
        verificar("mensagem inicial", () -> exigir(INICIAL.equals(texto(rotulo("Resultado da avaliação"))), "esperado: " + INICIAL));
        verificar("aprovação: \"  Ana   Silva  \" e 7,5 dão \"Ana Silva: Aprovado\"", () -> {
            conferir("  Ana   Silva  ", "7,5");
            igual("Ana Silva: Aprovado", texto(rotulo("Resultado da avaliação")));
            vazio(texto(rotulo("Erro do nome")), "Erro do nome");
            vazio(texto(rotulo("Erro da nota")), "Erro da nota");
        });
        verificar("recuperação: Bia e 6,5 dão \"Bia: Em recuperação\"", () -> {
            conferir("Bia", "6,5");
            igual("Bia: Em recuperação", texto(rotulo("Resultado da avaliação")));
        });
        verificar("nota inválida: erro junto à nota, nenhum erro no nome", () -> {
            conferir("Ana", "abc");
            igual("Use um número de 0 a 10.", texto(rotulo("Erro da nota")));
            vazio(texto(rotulo("Erro do nome")), "Erro do nome");
            igual("Corrija os campos indicados.", texto(rotulo("Resultado da avaliação")));
        });
        verificar("nome ausente: erro junto ao nome, nenhum erro na nota", () -> {
            conferir("", "7");
            igual("Informe o nome.", texto(rotulo("Erro do nome")));
            vazio(texto(rotulo("Erro da nota")), "Erro da nota");
            igual("Corrija os campos indicados.", texto(rotulo("Resultado da avaliação")));
        });
        verificar("dois erros ao mesmo tempo aparecem juntos", () -> {
            conferir("Ana3", "11");
            igual("Use apenas letras, espaços, hífen e apóstrofo.", texto(rotulo("Erro do nome")));
            igual("Use um número de 0 a 10.", texto(rotulo("Erro da nota")));
        });
        verificar("as mensagens cabem na janela no tamanho inicial (nada é cortado)", () -> {
            conferir("Ana3", "11");
            dispor(form);
            for (String quem : new String[] {"Erro do nome", "Erro da nota", "Resultado da avaliação"}) cabe(rotulo(quem));
            String nomeLongo = "Maria Aparecida Conceição de Albuquerque Siqueira Lima Neto";
            exigir(nomeLongo.length() <= 60, "o nome de teste deve ter no máximo 60 caracteres");
            conferir(nomeLongo, "6,5");
            dispor(form);
            cabe(rotulo("Resultado da avaliação"));
        });
        verificar("corrigir os campos apaga as mensagens de erro", () -> {
            conferir("Ana3", "11");
            conferir("Ana", "8");
            vazio(texto(rotulo("Erro do nome")), "Erro do nome");
            vazio(texto(rotulo("Erro da nota")), "Erro da nota");
            igual("Ana: Aprovado", texto(rotulo("Resultado da avaliação")));
        });
        verificar("Limpar esvazia campos e mensagens e restaura a mensagem inicial", () -> {
            conferir("Ana3", "11");
            naEdt(() -> botao("Limpar").doClick(0));
            igual("", texto(campo("Nome do aluno")));
            igual("", texto(campo("Nota (0 a 10)")));
            vazio(texto(rotulo("Erro do nome")), "Erro do nome");
            vazio(texto(rotulo("Erro da nota")), "Erro da nota");
            igual(INICIAL, texto(rotulo("Resultado da avaliação")));
        });
        verificar("as 11 entradas de nota do capítulo seguem o resultado da regra", () -> {
            String[] entradas = {"7", "10", "7,5", "0", "6.99", "", "abc", "-1", "11", "NaN", "Infinity"};
            for (String entrada : entradas) {
                String situacao = null, erro = null;
                try {
                    situacao = Nota.avaliar(entrada);
                } catch (IllegalArgumentException e) {
                    erro = e.getMessage();
                }
                conferir("Ana", entrada);
                if (erro == null) igual("Ana: " + situacao, texto(rotulo("Resultado da avaliação")));
                else igual(erro, texto(rotulo("Erro da nota")));
            }
        });

        if (consulta) {
            verificar("D1: durante a consulta o botão fica desativado e a tela avisa \"Consultando...\"", () -> {
                naEdt(() -> {
                    campo("Nome do aluno").setText("Ana Silva");
                    campo("Nota (0 a 10)").setText("7,5");
                    botao("Conferir").doClick(0);
                    exigir(!botao("Conferir").isEnabled(), "Conferir deve ficar desativado enquanto a consulta roda");
                    igual("Consultando...", texto(rotulo("Resultado da avaliação")));
                    return null;
                });
                AtomicBoolean respondeu = new AtomicBoolean(false);
                SwingUtilities.invokeLater(() -> respondeu.set(true));
                Thread.sleep(400);
                exigir(respondeu.get(), "a thread de eventos ficou bloqueada durante a consulta");
                esperarConsulta();
                igual("Ana Silva: Aprovado", texto(rotulo("Resultado da avaliação")));
                exigir(botao("Conferir").isEnabled(), "Conferir deve voltar a ficar ativo ao terminar");
            });
        }

        int total = passaram + FALHAS.size();
        for (String falha : FALHAS) System.out.println("FALHA  " + falha);
        System.out.println(passaram + " de " + total + " verificações de interface passaram.");
        System.out.println("MANUAL (exige janela e teclado reais; este programa não verifica):");
        System.out.println("  - Tab e Shift+Tab percorrem Nome, Nota, Conferir, Limpar; Enter aciona Conferir; Alt+C e Alt+L acionam os botões.");
        System.out.println("  - Depois de Conferir com erro o foco vai ao primeiro campo inválido; depois de Limpar, ao campo do nome.");
        System.out.println("  - A janela abre, redimensiona até o tamanho mínimo sem cortar texto e fecha.");
        System.exit(FALHAS.isEmpty() ? 0 : 1);
    }

    // ---------------------------------------------------------------- apoio

    private static void verificar(String nome, Corpo corpo) {
        try {
            if (form == null && !nome.startsWith("o formulário monta")) throw new AssertionError("o formulário não montou");
            corpo.executar();
            passaram++;
        } catch (Throwable erro) {
            Throwable causa = erro.getCause() != null && erro instanceof java.lang.reflect.InvocationTargetException ? erro.getCause() : erro;
            String detalhe = causa.getMessage() != null ? causa.getMessage() : causa.getClass().getSimpleName();
            // Várias verificações dependem do mesmo componente: a causa é mostrada uma vez só.
            FALHAS.add(nome + " -> " + (CAUSAS.add(detalhe) ? detalhe : "(mesma causa da falha anterior)"));
        }
    }

    private static void exigir(boolean condicao, String mensagem) {
        if (!condicao) throw new AssertionError(mensagem);
    }

    private static void igual(String esperado, String obtido) {
        if (!esperado.equals(obtido)) throw new AssertionError("esperado \"" + esperado + "\" mas apareceu \"" + obtido + "\"");
    }

    private static void cabe(JLabel rotulo) throws Exception {
        int largura = naEdt(() -> rotulo.getWidth());
        int preferida = naEdt(() -> rotulo.getPreferredSize().width);
        if (largura < preferida) {
            throw new AssertionError("o texto \"" + rotulo.getText() + "\" precisa de " + preferida + " px e só há " + largura + " px: aumente a largura inicial da janela ou deixe a coluna crescer");
        }
    }

    private static void vazio(String texto, String quem) {
        if (!texto.isBlank()) throw new AssertionError(quem + " deveria estar vazio, mas mostra \"" + texto + "\"");
    }

    private static <T> T naEdt(Callable<T> tarefa) throws Exception {
        if (SwingUtilities.isEventDispatchThread()) return tarefa.call();
        Object[] saida = new Object[2];
        SwingUtilities.invokeAndWait(() -> {
            try {
                saida[0] = tarefa.call();
            } catch (Throwable t) {
                saida[1] = t;
            }
        });
        if (saida[1] instanceof Exception e) throw e;
        if (saida[1] instanceof Error e) throw e;
        @SuppressWarnings("unchecked") T valor = (T) saida[0];
        return valor;
    }

    private static void naEdt(Runnable tarefa) throws Exception {
        naEdt(() -> {
            tarefa.run();
            return null;
        });
    }

    private static void dispor(Container c) {
        c.doLayout();
        for (Component filho : c.getComponents()) if (filho instanceof Container k) dispor(k);
    }

    private static void coletar(Component c, List<Component> saida) {
        saida.add(c);
        if (c instanceof Container k) for (Component filho : k.getComponents()) coletar(filho, saida);
    }

    /**
     * Nome que um leitor de tela anunciaria. Para campos de texto é o rótulo ligado por JLabel.setLabelFor
     * (propriedade "labeledBy"); não se consulta o contexto de acessibilidade do JTextField porque, sem janela,
     * criá-lo faz o Swing pedir a posição na tela e falhar. Para os demais, usa o nome acessível do componente.
     */
    private static String nomeAcessivel(Component c) {
        if (c instanceof JTextField f) {
            Object rotulo = f.getClientProperty("labeledBy");
            return rotulo instanceof JLabel l && l.getText() != null ? l.getText().trim() : "";
        }
        if (c instanceof Accessible a && a.getAccessibleContext() != null && a.getAccessibleContext().getAccessibleName() != null) {
            return a.getAccessibleContext().getAccessibleName().trim();
        }
        return "";
    }

    private static JTextField campo(String inicio) {
        for (Component c : todos) {
            if (c instanceof JTextField f && nomeAcessivel(f).toLowerCase().startsWith(inicio.toLowerCase())) return f;
        }
        throw new AssertionError("não há campo de texto com nome acessível começando por \"" + inicio + "\" (ligue um JLabel ao campo com setLabelFor)");
    }

    private static JLabel rotulo(String nomeAcessivel) {
        for (Component c : todos) {
            if (c instanceof JLabel l && nomeAcessivel(l).equals(nomeAcessivel)) return l;
        }
        throw new AssertionError("não há JLabel com nome acessível \"" + nomeAcessivel + "\" (use getAccessibleContext().setAccessibleName)");
    }

    private static AbstractButton botao(String texto) {
        for (Component c : todos) {
            if (c instanceof JButton b && texto.equals(b.getText())) return b;
        }
        throw new AssertionError("não há botão com o texto \"" + texto + "\"");
    }

    private static int topo(Component c) {
        return SwingUtilities.convertPoint(c, 0, 0, form).y;
    }

    private static int esquerda(Component c) {
        return SwingUtilities.convertPoint(c, 0, 0, form).x;
    }

    private static String texto(Component c) throws Exception {
        return naEdt(() -> c instanceof JTextField f ? f.getText() : c instanceof JLabel l ? l.getText() : ((AbstractButton) c).getText());
    }

    private static void conferir(String nome, String nota) throws Exception {
        naEdt(() -> {
            campo("Nome do aluno").setText(nome);
            campo("Nota (0 a 10)").setText(nota);
            botao("Conferir").doClick(0);
        });
        esperarConsulta();
    }

    /** Aceita tanto a versão síncrona quanto a do D1: espera o botão voltar a ficar ativo. */
    private static void esperarConsulta() throws Exception {
        for (int i = 0; i < 60; i++) {
            if (naEdt(() -> botao("Conferir").isEnabled())) return;
            Thread.sleep(100);
        }
        throw new AssertionError("a consulta não terminou em 6 segundos");
    }
}
