package br.estudo;

import javax.swing.JFrame;
import javax.swing.SwingUtilities;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(Main::abrir);
    }

    private static void abrir() {
        JFrame janela = new JFrame("Notas de estudo");
        janela.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        FormularioNotas formulario = new FormularioNotas();
        janela.setContentPane(formulario);
        janela.getRootPane().setDefaultButton(formulario.botaoPadrao());
        janela.pack();
        janela.setMinimumSize(janela.getSize());
        janela.setLocationRelativeTo(null);
        janela.setVisible(true);
    }
}
