package br.estudo.notas;
public final class Regra {
    private Regra() {}
    public static boolean aprovado(String texto) {
        if (texto == null || texto.trim().isEmpty()) throw new IllegalArgumentException();
        final double nota;
        try { nota=Double.parseDouble(texto.trim().replace(',', '.')); }
        catch (NumberFormatException e) { throw new IllegalArgumentException(); }
        if (Double.isNaN(nota) || Double.isInfinite(nota) || nota<0 || nota>10) throw new IllegalArgumentException();
        return nota>=7;
    }
}
