package br.estudo.notas;
import android.app.Activity;
import android.os.Bundle;
import android.widget.*;
public class MainActivity extends Activity {
    private TextView resultado;
    @Override public void onCreate(Bundle estado) {
        super.onCreate(estado);setContentView(R.layout.activity_main);
        if (android.os.Build.VERSION.SDK_INT >= 35) {
            android.view.View raiz=findViewById(android.R.id.content);
            raiz.setOnApplyWindowInsetsListener((view,insets) -> {
                android.graphics.Insets bordas=insets.getInsets(android.view.WindowInsets.Type.systemBars()
                    | android.view.WindowInsets.Type.displayCutout() | android.view.WindowInsets.Type.ime());
                view.setPadding(bordas.left,bordas.top,bordas.right,bordas.bottom);
                return insets;
            });
            raiz.requestApplyInsets();
        }
        EditText nota=findViewById(R.id.nota);resultado=findViewById(R.id.resultado);
        if (estado!=null) resultado.setText(estado.getCharSequence("resultado",getText(R.string.inicio)));
        findViewById(R.id.conferir).setOnClickListener(view -> {
            try { resultado.setText(Regra.aprovado(nota.getText().toString())?R.string.aprovado:R.string.recuperacao);nota.setError(null); }
            catch (IllegalArgumentException erro) { nota.setError(getString(R.string.invalida));resultado.setText(R.string.invalida); }
        });
    }
    @Override public void onSaveInstanceState(Bundle estado) {
        estado.putCharSequence("resultado",resultado.getText());super.onSaveInstanceState(estado);
    }
}
