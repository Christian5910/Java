import br.estudo.notas.Regra;
public class TestesRegra {
 public static void main(String[] args) {
  if (!Regra.aprovado("7,5") || Regra.aprovado("6")) throw new AssertionError();
  int total=2;
  for (String texto : new String[]{null,"","abc","NaN","Infinity","-1","11"}) {
   try { Regra.aprovado(texto); throw new AssertionError(texto); } catch (IllegalArgumentException esperado) { total++; }
  }
  System.out.println(total+" verificações de regra Android passaram.");
 }
}
