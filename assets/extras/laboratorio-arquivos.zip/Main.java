import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Arrays;
import java.util.List;

public class Main {
    public static void main(String[] args) throws IOException {
        Path diretorio = Paths.get("dados-estudo");
        Files.createDirectories(diretorio);
        Path destino = diretorio.resolve("alunos.txt");
        Path temporario = Files.createTempFile(diretorio, "alunos-", ".tmp");
        List<String> linhas = Arrays.asList("versao=1", "A01;João;8", "A02;Ana;9");
        try {
            Files.write(temporario, linhas, StandardCharsets.UTF_8);
            try {
                Files.move(temporario, destino, StandardCopyOption.ATOMIC_MOVE,
                    StandardCopyOption.REPLACE_EXISTING);
            } catch (AtomicMoveNotSupportedException erro) {
                throw new IOException("Substituição atômica indisponível neste ambiente", erro);
            }
            List<String> recuperadas = Files.readAllLines(destino, StandardCharsets.UTF_8);
            if (!recuperadas.equals(linhas)) throw new IOException("Conferência divergente");
            System.out.println("Gravação e leitura conferidas");
            for (String linha : recuperadas) System.out.println(linha);
        } finally {
            Files.deleteIfExists(temporario);
        }
    }
}