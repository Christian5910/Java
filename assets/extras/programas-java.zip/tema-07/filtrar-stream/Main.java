import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {
        List<Integer> notas = Arrays.asList(5, 7, 9, 7);
        List<Integer> aprovadas = notas.stream()
            .filter(n -> n >= 7)
            .sorted()
            .collect(Collectors.toList());
        System.out.println(aprovadas);
        System.out.println(notas);
    }
}