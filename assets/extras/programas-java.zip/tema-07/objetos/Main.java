public class Main {
    public static void main(String[] args) {
        Celular a = new Celular("A");
        Celular b = new Celular("B");
        a.bateria = 50;
        System.out.println(a.modelo + ": " + a.bateria);
        System.out.println(b.modelo + ": " + b.bateria);
    }
}

class Celular {
    String modelo;
    int bateria = 100;
    Celular(String modelo) { this.modelo = modelo; }
}
