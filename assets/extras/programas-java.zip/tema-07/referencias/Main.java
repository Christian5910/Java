public class Main {
    public static void main(String[] args) {
        Caixa original = new Caixa(1);
        alterar(original);
        System.out.println("Valor no objeto original: " + original.valor);
    }

    static void alterar(Caixa caixa) {
        caixa.valor = 9;
        caixa = new Caixa(100);
    }
}

class Caixa {
    int valor;
    Caixa(int valor) { this.valor = valor; }
}
