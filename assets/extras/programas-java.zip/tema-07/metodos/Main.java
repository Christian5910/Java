public class Main {
    public static void main(String[] args) {
        double dolares = converter(105.0, 5.25);
        System.out.printf(java.util.Locale.US, "Dólares: %.2f%n", dolares);
    }

    static double converter(double reais, double cotacao) {
        if (!Double.isFinite(reais) || reais < 0 || !Double.isFinite(cotacao) || cotacao <= 0) {
            throw new IllegalArgumentException("Valor ou cotação inválidos");
        }
        return reais / cotacao;
    }
}
