interface Mensagem {
    String texto();
}

class BoasVindas implements Mensagem {
    @Override
    public String texto() {
        return "Bem-vindo ao estudo";
    }
}

class Lembrete implements Mensagem {
    @Override
    public String texto() {
        return "Revise o exemplo antes de executar";
    }
}

public class Main {
    static void apresentar(Mensagem mensagem) {
        System.out.println(mensagem.texto());
    }

    public static void main(String[] args) {
        apresentar(new BoasVindas());
        apresentar(new Lembrete());
    }
}