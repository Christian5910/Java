public class Main {
    public static void main(String[] args) {
        System.out.println("Inteiros: " + somar(2, 3));
        System.out.println("Decimais: " + somar(2.5, 3.0));
    }

    static int somar(int a, int b) { return a + b; }
    static double somar(double a, double b) { return a + b; }
}
