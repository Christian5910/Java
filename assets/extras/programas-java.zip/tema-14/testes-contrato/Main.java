public class Main {
    static int acrescentar(int atual, int quantidade) {
        if (atual < 0 || quantidade <= 0) throw new IllegalArgumentException("Dados inválidos");
        return Math.addExact(atual, quantidade);
    }
    static void conferir(boolean condicao, String nome) {
        if (!condicao) throw new AssertionError(nome);
    }
    public static void main(String[] args) {
        conferir(acrescentar(0, 3) == 3, "Entrada inicial");
        conferir(acrescentar(3, 2) == 5, "Acumulação");
        boolean recusouZero = false;
        try { acrescentar(3, 0); }
        catch (IllegalArgumentException esperado) { recusouZero = true; }
        conferir(recusouZero, "Recusar zero");
        boolean recusouNegativo = false;
        try { acrescentar(-1, 2); }
        catch (IllegalArgumentException esperado) { recusouNegativo = true; }
        conferir(recusouNegativo, "Recusar estado negativo");
        System.out.println("4 cenários verificados");
    }
}