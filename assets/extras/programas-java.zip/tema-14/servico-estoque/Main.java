import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

class Estoque {
    private final Map<String, Integer> itens = new LinkedHashMap<>();
    private static void validar(String id, int quantidade) {
        if (id == null || id.trim().isEmpty() || quantidade <= 0) {
            throw new IllegalArgumentException("Dados inválidos");
        }
    }
    void receber(String id, int quantidade) {
        validar(id, quantidade);
        int novo = Math.addExact(itens.getOrDefault(id, 0), quantidade);
        itens.put(id, novo);
    }
    boolean retirar(String id, int quantidade) {
        validar(id, quantidade);
        int atual = itens.getOrDefault(id, 0);
        if (quantidade > atual) return false;
        itens.put(id, atual - quantidade);
        return true;
    }
    Map<String, Integer> consultar() {
        return Collections.unmodifiableMap(new LinkedHashMap<>(itens));
    }
}

public class Main {
    public static void main(String[] args) {
        Estoque estoque = new Estoque();
        estoque.receber("A", 5);
        System.out.println("Retirada aceita: " + estoque.retirar("A", 2));
        Map<String, Integer> fotografia = estoque.consultar();
        System.out.println("Retirada recusada: " + estoque.retirar("A", 4));
        System.out.println("Estoque: " + estoque.consultar());
        estoque.receber("A", 1);
        System.out.println("Fotografia anterior: " + fotografia);
    }
}