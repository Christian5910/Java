public class Main {
    public static void main(String[] args) {
        Produto produto = new Produto("  Caderno  ", 3);
        System.out.println(produto.getNome() + ": " + produto.getQuantidade());
        try {
            new Produto(" ", 2);
        } catch (IllegalArgumentException erro) {
            System.out.println(erro.getMessage());
        }
    }
}

class Produto {
    private final String nome;
    private final int quantidade;
    Produto(String nome, int quantidade) {
        if (nome == null || nome.trim().isEmpty() || quantidade < 0) {
            throw new IllegalArgumentException("Nome ou quantidade inválidos");
        }
        this.nome = nome.trim();
        this.quantidade = quantidade;
    }
    public String getNome() { return nome; }
    public int getQuantidade() { return quantidade; }
}
