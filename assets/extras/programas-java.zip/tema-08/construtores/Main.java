public class Main {
    public static void main(String[] args) {
        Circulo padrao = new Circulo();
        Circulo maior = new Circulo(2);
        System.out.printf(java.util.Locale.US, "Áreas: %.2f e %.2f%n", padrao.area(), maior.area());
    }
}

class Circulo {
    private double raio;
    Circulo() { this(1.0); }
    Circulo(double raio) {
        if (!Double.isFinite(raio) || raio <= 0) {
            throw new IllegalArgumentException("Raio inválido");
        }
        this.raio = raio;
    }
    double area() { return Math.PI * raio * raio; }
}
