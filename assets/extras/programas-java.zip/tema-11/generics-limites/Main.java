import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Main {
    static <T> void copiar(List<? extends T> origem, List<? super T> destino) {
        for (T valor : origem) destino.add(valor);
    }
    public static void main(String[] args) {
        List<Integer> inteiros = Arrays.asList(2, 4, 6);
        List<Number> numeros = new ArrayList<>();
        copiar(inteiros, numeros);
        copiar(Arrays.asList(1.5, 2.5), numeros);
        System.out.println(numeros);
        System.out.println("Origem: " + inteiros);
    }
}