import java.util.HashMap;
import java.util.HashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

public class Main {
    public static void main(String[] args) {
        Set<Produto> cadastro = new HashSet<>();
        boolean primeiro = cadastro.add(new Produto("x-1", "Caneta"));
        boolean repetido = cadastro.add(new Produto(" X-1 ", "Caneta azul"));
        boolean outro = cadastro.add(new Produto("Y-2", "Lápis"));
        System.out.println(primeiro + " " + repetido + " " + outro);
        System.out.println("Tamanho: " + cadastro.size());
        System.out.println("Contém X-1: " + cadastro.contains(new Produto("X-1", "qualquer")));
        Map<Produto, Integer> estoque = new HashMap<>();
        estoque.put(new Produto("X-1", "a"), 5);
        estoque.put(new Produto("x-1", "b"), 7);
        System.out.println("Estoque de X-1: " + estoque.get(new Produto("X-1", "c")) + " em " + estoque.size() + " chave(s)");
        Produto produto = new Produto("X-1", "Caneta");
        System.out.println(produto.equals(null) + " " + produto.equals("X-1"));
    }
}

class Produto {
    private final String sku;
    private final String nome;

    Produto(String sku, String nome) {
        this.sku = sku.trim().toUpperCase(Locale.ROOT);
        this.nome = nome;
    }

    @Override
    public boolean equals(Object outro) {
        if (this == outro) return true;
        if (outro == null || getClass() != outro.getClass()) return false;
        return sku.equals(((Produto) outro).sku);
    }

    @Override
    public int hashCode() {
        return sku.hashCode();
    }
}
