import java.util.HashSet;
import java.util.Set;

public class Main {
    public static void main(String[] args) {
        Set<ClienteMutavel> clientes = new HashSet<>();
        ClienteMutavel ana = new ClienteMutavel("ana@exemplo.com");
        clientes.add(ana);
        System.out.println("Antes: " + clientes.contains(ana));
        ana.setEmail("ana.silva@exemplo.com");
        System.out.println("Depois: " + clientes.contains(ana));
        System.out.println("Tamanho: " + clientes.size());
        boolean removido = clientes.remove(ana);
        System.out.println("Removido: " + removido + ", tamanho " + clientes.size());

        Set<Cliente> corrigido = new HashSet<>();
        Cliente antigo = new Cliente("ana@exemplo.com");
        corrigido.add(antigo);
        Cliente novo = antigo.comEmail("ana.silva@exemplo.com");
        corrigido.remove(antigo);
        corrigido.add(novo);
        System.out.println("Corrigido: " + corrigido.contains(novo) + ", tamanho " + corrigido.size());
    }
}

class ClienteMutavel {
    private String email;

    ClienteMutavel(String email) {
        this.email = email;
    }

    void setEmail(String email) {
        this.email = email;
    }

    @Override
    public boolean equals(Object outro) {
        return outro instanceof ClienteMutavel && email.equals(((ClienteMutavel) outro).email);
    }

    @Override
    public int hashCode() {
        return email.hashCode();
    }
}

class Cliente {
    private final String email;

    Cliente(String email) {
        this.email = email;
    }

    Cliente comEmail(String novoEmail) {
        return new Cliente(novoEmail);
    }

    @Override
    public boolean equals(Object outro) {
        return outro instanceof Cliente && email.equals(((Cliente) outro).email);
    }

    @Override
    public int hashCode() {
        return email.hashCode();
    }
}
