import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

class Aluno {
    private final String nome;
    private final int nota;
    Aluno(String nome, int nota) {
        if (nome == null || nome.trim().isEmpty() || nota < 0 || nota > 10) {
            throw new IllegalArgumentException("Aluno inválido");
        }
        this.nome = nome;
        this.nota = nota;
    }
    String getNome() { return nome; }
    int getNota() { return nota; }
    @Override public String toString() { return nome + ":" + nota; }
}

public class Main {
    public static void main(String[] args) {
        List<Aluno> cadastro = Arrays.asList(
            new Aluno("Carla", 7), new Aluno("Ana", 9), new Aluno("Bruno", 7));
        List<Aluno> consulta = new ArrayList<>(cadastro);
        consulta.sort(Comparator.comparingInt(Aluno::getNota).reversed()
            .thenComparing(Aluno::getNome));
        System.out.println("Consulta: " + consulta);
        System.out.println("Cadastro: " + cadastro);
    }
}