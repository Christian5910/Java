public class Main {
    public static void main(String[] args) {
        System.out.print("Olá, ");
        System.out.println("Java!");
        System.out.println("Soma: " + (5 + 10));
    }
}
