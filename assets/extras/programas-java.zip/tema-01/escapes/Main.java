public class Main {
    public static void main(String[] args) {
        System.out.println("Linha 1\nLinha 2");
        System.out.println("Caminho: C:\\estudos\\Main.java");
        System.out.printf("Total: %d%n", 3 + 4);
    }
}
