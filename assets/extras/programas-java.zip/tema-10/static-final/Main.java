public class Main {
    public static void main(String[] args) {
        Registro a = new Registro();
        Registro b = new Registro();
        System.out.println("IDs: " + a.getId() + ", " + b.getId());
        System.out.println("Próximo ID: " + Registro.getProximoId());
    }
}

class Registro {
    private static int proximoId = 1;
    private final int id;
    Registro() { id = proximoId++; }
    public int getId() { return id; }
    public static int getProximoId() { return proximoId; }
}
