public class Main {
    public static void main(String[] args) {
        Produto produto = new Produto(10);
        System.out.println("Estoque: " + produto.getEstoque());
    }
}

class Produto {
    private int estoque;
    Produto(int estoque) { this.estoque = estoque; }
    public int getEstoque() { return estoque; }
}
