import java.util.Locale;

public class Main {
    public static void main(String[] args) {
        System.out.println(Codigo.de("  abc-123 ").getTexto());
        String[] tentativas = {"AB-123", "ABC-12", "ABC123", null};
        for (String tentativa : tentativas) {
            try {
                Codigo.de(tentativa);
                System.out.println("Aceito: " + tentativa);
            } catch (IllegalArgumentException erro) {
                System.out.println(erro.getMessage() + ": " + tentativa);
            }
        }
    }
}

class Codigo {
    private final String texto;

    private Codigo(String texto) {
        this.texto = texto;
    }

    public static Codigo de(String entrada) {
        if (entrada == null) throw new IllegalArgumentException("Código inválido");
        String normal = entrada.trim().toUpperCase(Locale.ROOT);
        if (!normal.matches("[A-Z]{3}-[0-9]{3}")) throw new IllegalArgumentException("Código inválido");
        return new Codigo(normal);
    }

    public String getTexto() {
        return texto;
    }
}
