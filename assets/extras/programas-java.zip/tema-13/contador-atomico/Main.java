import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicInteger;

public class Main {
    public static void main(String[] args) throws Exception {
        AtomicInteger contador = new AtomicInteger();
        ExecutorService executor = Executors.newFixedThreadPool(2);
        List<Future<?>> tarefas = new ArrayList<>();
        try {
            for (int t = 0; t < 4; t++) {
                tarefas.add(executor.submit(() -> {
                    for (int i = 0; i < 1000; i++) contador.incrementAndGet();
                }));
            }
            for (Future<?> tarefa : tarefas) tarefa.get();
            System.out.println("Total: " + contador.get());
        } finally {
            executor.shutdownNow();
        }
    }
}