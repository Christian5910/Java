import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class Main {
    public static void main(String[] args) throws Exception {
        ExecutorService executor = Executors.newFixedThreadPool(2);
        try {
            Future<Integer> primeira = executor.submit(() -> 12 * 12);
            Future<Integer> segunda = executor.submit(() -> 7 * 7);
            System.out.println("Primeira: " + primeira.get());
            System.out.println("Segunda: " + segunda.get());
            System.out.println("Soma: " + (primeira.get() + segunda.get()));
        } finally {
            executor.shutdownNow();
        }
    }
}