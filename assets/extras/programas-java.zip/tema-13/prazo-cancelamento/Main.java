import java.util.concurrent.CancellationException;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicBoolean;

public class Main {
    public static void main(String[] args) throws Exception {
        ExecutorService executor = Executors.newSingleThreadExecutor();
        CountDownLatch encerrada = new CountDownLatch(1);
        AtomicBoolean viuInterrupcao = new AtomicBoolean(false);
        try {
            Future<String> tarefa = executor.submit(() -> {
                try {
                    Thread.sleep(3000);
                    return "concluída";
                } catch (InterruptedException erro) {
                    viuInterrupcao.set(true);
                    Thread.currentThread().interrupt();
                    throw erro;
                } finally {
                    encerrada.countDown();
                }
            });
            try {
                tarefa.get(200, TimeUnit.MILLISECONDS);
            } catch (TimeoutException erro) {
                System.out.println("Prazo esgotado");
            }
            boolean cancelada = tarefa.cancel(true);
            boolean terminou = encerrada.await(2, TimeUnit.SECONDS);
            System.out.println("Cancelada: " + cancelada + ", isCancelled: " + tarefa.isCancelled());
            System.out.println("Tarefa terminou: " + terminou + ", viu a interrupção: " + viuInterrupcao.get());
            try {
                tarefa.get();
            } catch (CancellationException erro) {
                System.out.println("get depois de cancelar: CancellationException");
            }
        } finally {
            executor.shutdownNow();
        }
    }
}
