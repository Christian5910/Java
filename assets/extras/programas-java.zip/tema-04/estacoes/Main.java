import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        if (!entrada.hasNextInt()) {
            System.out.println("Informe uma opção inteira");
            return;
        }
        String estacao = switch (entrada.nextInt()) {
            case 1 -> "Primavera";
            case 2 -> "Verão";
            case 3 -> "Outono";
            case 4 -> "Inverno";
            default -> "Estação desconhecida";
        };
        System.out.println(estacao);
    }
}
