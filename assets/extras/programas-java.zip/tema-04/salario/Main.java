import java.util.Locale;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in).useLocale(Locale.US);
        double horas = entrada.nextDouble();
        if (!Double.isFinite(horas) || horas < 0) {
            System.out.println("Horas inválidas");
            return;
        }
        double salario = horas <= 40 ? horas * 15 : 600 + (horas - 40) * 21;
        System.out.printf(Locale.US, "Salário: R$ %.2f%n", salario);
    }
}
