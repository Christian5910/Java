import java.util.Locale;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in).useLocale(Locale.US);
        double a = entrada.nextDouble();
        double b = entrada.nextDouble();
        String operacao = entrada.next();
        if (!Double.isFinite(a) || !Double.isFinite(b)) {
            System.out.println("Números inválidos");
            return;
        }
        double resultado;
        switch (operacao) {
            case "+" -> resultado = a + b;
            case "-" -> resultado = a - b;
            case "*" -> resultado = a * b;
            case "/" -> {
                if (b == 0) {
                    System.out.println("Divisão por zero");
                    return;
                }
                resultado = a / b;
            }
            default -> {
                System.out.println("Operação desconhecida");
                return;
            }
        }
        System.out.println("Resultado: " + resultado);
    }
}
