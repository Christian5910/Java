import java.util.Locale;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in).useLocale(Locale.US);
        double media = entrada.nextDouble();
        double presenca = entrada.nextDouble();
        if (!Double.isFinite(media) || !Double.isFinite(presenca)
                || media < 0 || media > 10 || presenca < 0 || presenca > 100) {
            System.out.println("Dados inválidos");
        } else if (media >= 7 && presenca >= 75) {
            System.out.println("Critérios atendidos");
        } else {
            System.out.println("Critérios não atendidos");
        }
    }
}
