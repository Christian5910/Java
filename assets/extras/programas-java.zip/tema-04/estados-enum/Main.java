enum Situacao {
    PENDENTE, EM_ANDAMENTO, CONCLUIDA
}

public class Main {
    public static void main(String[] args) {
        Situacao atual = Situacao.EM_ANDAMENTO;
        String mensagem = switch (atual) {
            case PENDENTE -> "Ainda não começou";
            case EM_ANDAMENTO -> "Estudo em andamento";
            case CONCLUIDA -> "Estudo concluído";
        };
        System.out.println(mensagem);
    }
}