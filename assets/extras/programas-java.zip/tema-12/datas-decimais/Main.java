import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class Main {
    public static void main(String[] args) {
        LocalDate inicio = LocalDate.of(2026, 10, 15);
        LocalDate prazo = inicio.plusDays(7);
        BigDecimal unitario = new BigDecimal("19.90");
        BigDecimal quantidade = new BigDecimal("3");
        BigDecimal fator = new BigDecimal("0.90");
        BigDecimal total = unitario.multiply(quantidade).multiply(fator)
            .setScale(2, RoundingMode.HALF_UP);
        System.out.println("Prazo: " + prazo.format(DateTimeFormatter.ISO_LOCAL_DATE));
        System.out.println("Total: " + total.toPlainString());
        System.out.println("Mesmo valor: " +
            (new BigDecimal("2.0").compareTo(new BigDecimal("2.00")) == 0));
    }
}