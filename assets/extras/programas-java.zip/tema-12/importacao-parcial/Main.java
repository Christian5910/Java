import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class Main {
    public static void main(String[] args) throws IOException {
        Map<String, Integer> aceitos = new LinkedHashMap<>();
        List<String> recusadas = new ArrayList<>();
        try (BufferedReader entrada = new BufferedReader(new InputStreamReader(System.in, StandardCharsets.UTF_8))) {
            int numero = 0;
            String linha;
            while ((linha = entrada.readLine()) != null) {
                numero++;
                String[] partes = linha.split(";", -1);
                String motivo = null;
                if (partes.length != 2) {
                    motivo = "formato inválido";
                } else if (partes[0].trim().isEmpty()) {
                    motivo = "identificador vazio";
                } else {
                    try {
                        int nota = Integer.parseInt(partes[1].trim());
                        if (nota < 0 || nota > 10) motivo = "nota fora de 0 a 10";
                        else if (aceitos.containsKey(partes[0].trim())) motivo = "identificador repetido";
                        else aceitos.put(partes[0].trim(), nota);
                    } catch (NumberFormatException erro) {
                        motivo = "nota inválida";
                    }
                }
                if (motivo != null) recusadas.add("Linha " + numero + ": " + motivo);
            }
        }
        System.out.println("Aceitos: " + aceitos);
        System.out.println("Recusadas: " + recusadas.size());
        for (String recusada : recusadas) System.out.println(recusada);
    }
}
