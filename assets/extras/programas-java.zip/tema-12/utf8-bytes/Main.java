import java.nio.charset.StandardCharsets;
import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        String texto = "ação";
        byte[] utf8 = texto.getBytes(StandardCharsets.UTF_8);
        byte[] latin1 = texto.getBytes(StandardCharsets.ISO_8859_1);
        System.out.println(texto.length() + " caracteres, " + utf8.length + " bytes em UTF-8, " + latin1.length + " bytes em ISO-8859-1");
        System.out.println("Bytes UTF-8: " + Arrays.toString(utf8));
        String lidoErrado = new String(utf8, StandardCharsets.ISO_8859_1);
        System.out.println("UTF-8 lido como ISO-8859-1: " + lidoErrado + " (" + lidoErrado.length() + " caracteres)");
        String lidoCerto = new String(utf8, StandardCharsets.UTF_8);
        System.out.println("UTF-8 lido como UTF-8: " + lidoCerto + " (" + lidoCerto.equals(texto) + ")");
    }
}
