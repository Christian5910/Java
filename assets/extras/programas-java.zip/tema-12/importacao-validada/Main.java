import java.io.BufferedReader;
import java.io.IOException;
import java.io.StringReader;
import java.util.LinkedHashMap;
import java.util.Map;

public class Main {
    static Map<String, Integer> importar(String texto) throws IOException {
        Map<String, Integer> novo = new LinkedHashMap<>();
        try (BufferedReader leitor = new BufferedReader(new StringReader(texto))) {
            String linha;
            int numero = 0;
            while ((linha = leitor.readLine()) != null) {
                numero++;
                String[] partes = linha.split(";", -1);
                if (partes.length != 2 || partes[0].trim().isEmpty()) {
                    throw new IllegalArgumentException("Linha " + numero + " inválida");
                }
                String id = partes[0].trim();
                int nota;
                try { nota = Integer.parseInt(partes[1].trim()); }
                catch (NumberFormatException erro) {
                    throw new IllegalArgumentException("Nota inválida na linha " + numero, erro);
                }
                if (nota < 0 || nota > 10 || novo.containsKey(id)) {
                    throw new IllegalArgumentException("Regra inválida na linha " + numero);
                }
                novo.put(id, nota);
            }
        }
        return novo;
    }
    public static void main(String[] args) throws IOException {
        Map<String, Integer> atual = importar("A01;8\nA02;7\n");
        System.out.println("Cadastro: " + atual);
        try { atual = importar("A03;9\nA04;texto\n"); }
        catch (IllegalArgumentException erro) { System.out.println(erro.getMessage()); }
        System.out.println("Após recusa: " + atual);
    }
}