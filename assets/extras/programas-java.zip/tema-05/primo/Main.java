import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        int numero = entrada.nextInt();
        boolean primo = numero >= 2;
        for (int divisor = 2; primo && divisor <= numero / divisor; divisor++) {
            if (numero % divisor == 0) primo = false;
        }
        System.out.println(numero + (primo ? " é primo" : " não é primo"));
    }
}
