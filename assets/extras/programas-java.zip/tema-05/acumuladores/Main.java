import java.util.Locale;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        long soma = 0;
        int quantidade = 0;
        while (entrada.hasNextInt()) {
            int valor = entrada.nextInt();
            if (valor == 0) break;
            if (valor < 0) continue;
            soma += valor;
            quantidade++;
        }
        System.out.println("Quantidade: " + quantidade);
        System.out.println("Soma: " + soma);
        if (quantidade == 0) System.out.println("Sem valores positivos");
        else System.out.printf(Locale.US, "Média: %.2f%n", (double) soma / quantidade);
    }
}
