import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        boolean continuar = true;
        while (continuar && entrada.hasNextInt()) {
            int opcao = entrada.nextInt();
            switch (opcao) {
                case 1 -> System.out.println("Consulta realizada");
                case 0 -> continuar = false;
                default -> System.out.println("Opção inválida");
            }
        }
        System.out.println("Menu encerrado");
    }
}
