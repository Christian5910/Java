public class Main {
    public static void main(String[] args) {
        int valor = 3;
        while (valor < 3) {
            System.out.println("while: " + valor);
            valor++;
        }
        do {
            System.out.println("do: " + valor);
            valor++;
        } while (valor < 3);
    }
}
