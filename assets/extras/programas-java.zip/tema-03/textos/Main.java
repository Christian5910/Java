public class Main {
    public static void main(String[] args) {
        String texto = "Java";
        String outro = new String("Java");
        System.out.println("Mesma referência: " + (texto == outro));
        System.out.println("Mesmo conteúdo: " + texto.equals(outro));
        System.out.println("Trecho: " + texto.substring(1, 3));
        System.out.println("Índice: " + texto.indexOf("z"));
    }
}
