import java.util.Locale;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        String original = entrada.hasNextLine() ? entrada.nextLine() : "";
        String comando = original.trim().toLowerCase(Locale.ROOT);
        if (comando.isEmpty()) {
            System.out.println("Comando vazio");
        } else {
            System.out.println("Comando: " + comando);
            System.out.println("Encerrar: " + "sair".equals(comando));
        }
    }
}
