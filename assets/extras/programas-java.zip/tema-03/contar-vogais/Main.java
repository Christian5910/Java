import java.util.Locale;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        String texto = entrada.hasNextLine() ? entrada.nextLine() : "";
        texto = texto.toLowerCase(Locale.ROOT);
        int quantidade = 0;
        for (int i = 0; i < texto.length(); i++) {
            if ("aeiou".indexOf(texto.charAt(i)) >= 0) quantidade++;
        }
        System.out.println("Vogais sem acento: " + quantidade);
    }
}
