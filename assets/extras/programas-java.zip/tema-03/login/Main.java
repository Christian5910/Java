import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        String usuario = entrada.nextLine();
        String senha = entrada.nextLine();
        boolean autorizado = validarLogin(usuario, senha);
        System.out.println(autorizado ? "Acesso permitido" : "Acesso negado");
    }

    static boolean validarLogin(String usuario, String senha) {
        return "admin".equals(usuario) && "12345".equals(senha);
    }
}
