import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class Main {
    public static void main(String[] args) {
        List<String> presencas = new ArrayList<>();
        presencas.add("Ana");
        presencas.add("Bruno");
        presencas.add("Ana");
        Set<String> pessoas = new LinkedHashSet<>(presencas);
        Map<String, Integer> notas = new LinkedHashMap<>();
        notas.put("Ana", 7);
        notas.put("Bruno", 8);
        notas.put("Ana", 9);
        System.out.println(presencas);
        System.out.println(pessoas);
        System.out.println(notas);
        System.out.println(notas.containsKey("Carla"));
    }
}