import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        int[][] matriz = {{1, 2, 3}, {4, 5, 6}};
        int[][] transposta = new int[matriz[0].length][matriz.length];
        for (int linha = 0; linha < matriz.length; linha++) {
            for (int coluna = 0; coluna < matriz[linha].length; coluna++) {
                transposta[coluna][linha] = matriz[linha][coluna];
            }
        }
        for (int[] linha : transposta) System.out.println(Arrays.toString(linha));
    }
}
