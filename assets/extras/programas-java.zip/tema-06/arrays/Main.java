public class Main {
    public static void main(String[] args) {
        double[] notas = {6.0, 7.0, 8.0};
        if (notas.length == 0) {
            System.out.println("Sem notas");
            return;
        }
        double soma = 0;
        double menor = notas[0];
        for (double nota : notas) {
            soma += nota;
            menor = Math.min(menor, nota);
        }
        System.out.println("Média: " + soma / notas.length);
        System.out.println("Menor: " + menor);
    }
}
