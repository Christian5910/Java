public class Main {
    public static void main(String[] args) {
        int[] valores = {4, 7, 4, 9};
        int procurado = 4;
        int primeira = -1;
        int ultima = -1;
        for (int i = 0; i < valores.length; i++) {
            if (valores[i] == procurado) {
                if (primeira == -1) primeira = i;
                ultima = i;
            }
        }
        System.out.println("Primeira: " + primeira);
        System.out.println("Última: " + ultima);
    }
}
