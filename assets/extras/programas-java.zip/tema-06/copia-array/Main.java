import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        int[] original = {3, 1, 2};
        int[] copia = Arrays.copyOf(original, original.length);
        Arrays.sort(copia);
        System.out.println("Original: " + Arrays.toString(original));
        System.out.println("Cópia: " + Arrays.toString(copia));
    }
}
