import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        ArrayList<String> nomes = new ArrayList<>();
        nomes.add("Ana");
        nomes.add("Bruno");
        for (String nome : nomes) {
            System.out.println(nome);
        }
        System.out.println("Quantidade: " + nomes.size());
    }
}
