public class Main {
    public static void main(String[] args) {
        int[][] matriz = {{1, 2, 3}, {4, 5}};
        int soma = 0;
        for (int linha = 0; linha < matriz.length; linha++) {
            for (int coluna = 0; coluna < matriz[linha].length; coluna++) {
                soma += matriz[linha][coluna];
            }
        }
        System.out.println("Linhas: " + matriz.length);
        System.out.println("Soma: " + soma);
    }
}
