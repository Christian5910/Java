import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        double[] entrada = {7.0, 8.0};
        Boletim boletim = new Boletim(entrada);
        entrada[0] = 0;
        double[] consulta = boletim.getNotas();
        consulta[1] = 0;
        System.out.println("Notas preservadas: " + Arrays.toString(boletim.getNotas()));
        System.out.println("Média: " + boletim.media());
    }
}

class Boletim {
    private final double[] notas;
    Boletim(double[] notas) {
        if (notas == null || notas.length == 0) {
            throw new IllegalArgumentException("Informe ao menos uma nota");
        }
        for (double nota : notas) {
            if (!Double.isFinite(nota) || nota < 0 || nota > 10) {
                throw new IllegalArgumentException("Nota inválida");
            }
        }
        this.notas = Arrays.copyOf(notas, notas.length);
    }
    public double[] getNotas() { return Arrays.copyOf(notas, notas.length); }
    public double media() {
        double soma = 0;
        for (double nota : notas) soma += nota;
        return soma / notas.length;
    }
}
