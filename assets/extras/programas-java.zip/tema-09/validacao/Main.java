public class Main {
    public static void main(String[] args) {
        Conta conta = new Conta(10000);
        try {
            conta.depositar(-100);
        } catch (IllegalArgumentException erro) {
            System.out.println(erro.getMessage());
        }
        System.out.println("Saldo preservado: " + conta.getSaldo());
    }
}

class Conta {
    private long saldo;
    Conta(long saldo) {
        if (saldo < 0) throw new IllegalArgumentException("Saldo negativo");
        this.saldo = saldo;
    }
    public long getSaldo() { return saldo; }
    public void depositar(long valor) {
        if (valor <= 0) throw new IllegalArgumentException("Depósito inválido");
        saldo = Math.addExact(saldo, valor);
    }
    public boolean sacar(long valor) {
        if (valor <= 0 || valor > saldo) return false;
        saldo -= valor;
        return true;
    }
}
