public class Main {
    static int lerQuantidade(String texto) {
        int quantidade = Integer.parseInt(texto);
        if (quantidade <= 0) {
            throw new IllegalArgumentException("Quantidade deve ser positiva");
        }
        return quantidade;
    }

    public static void main(String[] args) {
        String[] entradas = {"3", "zero", "0"};
        for (String texto : entradas) {
            try {
                System.out.println("Quantidade: " + lerQuantidade(texto));
            } catch (NumberFormatException erro) {
                System.out.println("Formato inválido: " + texto);
            } catch (IllegalArgumentException erro) {
                System.out.println(erro.getMessage());
            }
        }
    }
}