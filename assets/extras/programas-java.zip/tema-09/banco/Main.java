import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        Conta conta = new Conta(10000);
        boolean continuar = true;
        while (continuar && entrada.hasNextInt()) {
            int opcao = entrada.nextInt();
            switch (opcao) {
                case 1 -> System.out.println("Saldo: " + conta.getSaldo());
                case 2, 3 -> {
                    if (!entrada.hasNextLong()) {
                        System.out.println("Valor ausente ou inválido");
                        return;
                    }
                    long valor = entrada.nextLong();
                    try {
                        if (opcao == 2) conta.depositar(valor);
                        else System.out.println("Saque: " + conta.sacar(valor));
                    } catch (IllegalArgumentException erro) {
                        System.out.println(erro.getMessage());
                    }
                }
                case 0 -> continuar = false;
                default -> System.out.println("Opção inválida");
            }
        }
        System.out.println("Encerrado");
    }
}

class Conta {
    private long saldo;
    Conta(long saldo) {
        if (saldo < 0) throw new IllegalArgumentException("Saldo negativo");
        this.saldo = saldo;
    }
    public long getSaldo() { return saldo; }
    public void depositar(long valor) {
        if (valor <= 0) throw new IllegalArgumentException("Depósito inválido");
        saldo = Math.addExact(saldo, valor);
    }
    public boolean sacar(long valor) {
        if (valor <= 0 || valor > saldo) return false;
        saldo -= valor;
        return true;
    }
}
