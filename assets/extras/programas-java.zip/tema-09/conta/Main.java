public class Main {
    public static void main(String[] args) {
        Conta conta = new Conta(10000);
        conta.depositar(2500);
        System.out.println("Saque aceito: " + conta.sacar(3000));
        System.out.println("Saque excessivo: " + conta.sacar(99999));
        System.out.println("Saldo em centavos: " + conta.getSaldo());
    }
}

class Conta {
    private long saldo;
    Conta(long saldo) {
        if (saldo < 0) throw new IllegalArgumentException("Saldo negativo");
        this.saldo = saldo;
    }
    public long getSaldo() { return saldo; }
    public void depositar(long valor) {
        if (valor <= 0) throw new IllegalArgumentException("Depósito inválido");
        saldo = Math.addExact(saldo, valor);
    }
    public boolean sacar(long valor) {
        if (valor <= 0 || valor > saldo) return false;
        saldo -= valor;
        return true;
    }
}
