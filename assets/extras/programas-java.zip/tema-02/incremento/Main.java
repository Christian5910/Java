public class Main {
    public static void main(String[] args) {
        int x = 3;
        int anterior = x++;
        int atualizado = ++x;
        System.out.println("Anterior: " + anterior);
        System.out.println("Atualizado: " + atualizado);
        System.out.println("x: " + x);
    }
}
