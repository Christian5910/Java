import java.util.Locale;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in).useLocale(Locale.US);
        String nome = entrada.nextLine();
        double n1 = entrada.nextDouble();
        double n2 = entrada.nextDouble();
        double n3 = entrada.nextDouble();
        double media = (n1 + n2 + n3) / 3.0;
        System.out.printf(Locale.US, "%s: %.2f%n", nome, media);
        System.out.println(media >= 7 ? "Aprovado" : "Recuperação");
    }
}
