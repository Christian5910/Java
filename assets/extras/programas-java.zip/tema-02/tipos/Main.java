public class Main {
    public static void main(String[] args) {
        int a = 10;
        int b = 4;
        double inteira = a / b;
        double decimal = (double) a / b;
        System.out.println("Inteira: " + inteira);
        System.out.println("Decimal: " + decimal);
        System.out.println("Resto: " + (a % b));
    }
}
