import java.util.Random;

public class Main {
    public static void main(String[] args) {
        Random gerador = new Random(42);
        int dado = gerador.nextInt(6) + 1;
        System.out.println("Dado: " + dado);
        System.out.println("Teto: " + Math.ceil(-2.3));
        System.out.println("Piso: " + Math.floor(-2.3));
    }
}
