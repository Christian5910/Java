import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        boolean encontrou = false;
        while (entrada.hasNext()) {
            if (!entrada.hasNextInt()) {
                System.out.println("Token inválido: " + entrada.next());
                continue;
            }
            int nota = entrada.nextInt();
            if (nota < 0 || nota > 10) {
                System.out.println("Fora da faixa: " + nota);
                continue;
            }
            System.out.println("Nota aceita: " + nota);
            encontrou = true;
            break;
        }
        if (!encontrou) System.out.println("Nenhuma nota válida");
    }
}
