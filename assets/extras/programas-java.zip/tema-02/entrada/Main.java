import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        int idade = entrada.nextInt();
        entrada.nextLine(); // Consome o restante da linha da idade.
        String nome = entrada.nextLine();
        System.out.println(nome + " tem " + idade + " anos.");
    }
}
