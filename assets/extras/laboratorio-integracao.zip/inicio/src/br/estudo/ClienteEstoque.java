package br.estudo;

import java.net.URI;
import java.time.Duration;

/**
 * Seu trabalho: um cliente do serviço de estoque que admite falha. Ponto de partida: só a estrutura.
 * O contrato completo está no LEIA-ME (etapas 2 a 4).
 */
public class ClienteEstoque {
    private final URI base;
    private final Duration timeout;

    public ClienteEstoque(URI base, Duration timeout) {
        this.base = base;
        this.timeout = timeout;
    }

    /** Etapa 2: consulta o item (GET /itens/{id}). */
    public Resultado consultar(String id) {
        throw new UnsupportedOperationException("Etapa 2: implemente consultar");
    }

    /** Etapas 3 e 4: pede a retirada (POST /itens/{id}/retiradas) com a chave de operação. */
    public Resultado retirar(String id, int quantidade, int versao, String chave) {
        throw new UnsupportedOperationException("Etapas 3 e 4: implemente retirar");
    }
}
