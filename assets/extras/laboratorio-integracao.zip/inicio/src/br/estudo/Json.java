package br.estudo;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * JSON mínimo para objetos planos (texto, inteiro, decimal, booleano e nulo). Recusa o que não é um objeto bem
 * formado (texto cortado, vírgula sobrando, chave repetida, texto depois do objeto), mas não implementa todo o
 * padrão: por exemplo, aceita zeros à esquerda. Infraestrutura do laboratório, não uma biblioteca de JSON.
 * Texto inválido lança IllegalArgumentException.
 */
public final class Json {
    private final String s;
    private int i = 0;

    private Json(String s) {
        this.s = s;
    }

    public static Map<String, Object> objeto(String texto) {
        if (texto == null) throw erro("texto ausente");
        Json p = new Json(texto);
        Map<String, Object> mapa = new LinkedHashMap<>();
        p.espaco();
        p.esperar('{');
        p.espaco();
        if (p.proximo() == '}') {
            p.i++;
        } else {
            while (true) {
                p.espaco();
                String chave = p.texto();
                p.espaco();
                p.esperar(':');
                p.espaco();
                if (mapa.put(chave, p.valor()) != null) throw erro("chave repetida: " + chave);
                p.espaco();
                char c = p.ler();
                if (c == '}') break;
                if (c != ',') throw erro("esperava , ou } na posição " + (p.i - 1));
            }
        }
        p.espaco();
        if (p.i != texto.length()) throw erro("há texto depois do objeto");
        return mapa;
    }

    /** Valor inteiro obrigatório: ausente ou de outro tipo lança IllegalArgumentException. */
    public static int inteiro(Map<String, Object> objeto, String chave) {
        if (objeto.get(chave) instanceof Integer n) return n;
        throw erro("o campo " + chave + " deve ser um número inteiro");
    }

    public static String texto(Map<String, Object> objeto, String chave) {
        if (objeto.get(chave) instanceof String t) return t;
        throw erro("o campo " + chave + " deve ser um texto");
    }

    public static String escapar(String texto) {
        StringBuilder b = new StringBuilder("\"");
        for (char c : texto.toCharArray()) {
            switch (c) {
                case '"' -> b.append("\\\"");
                case '\\' -> b.append("\\\\");
                case '\n' -> b.append("\\n");
                case '\r' -> b.append("\\r");
                case '\t' -> b.append("\\t");
                default -> b.append(c < 0x20 ? String.format("\\u%04x", (int) c) : String.valueOf(c));
            }
        }
        return b.append('"').toString();
    }

    private static IllegalArgumentException erro(String mensagem) {
        return new IllegalArgumentException("JSON inválido: " + mensagem);
    }

    private char proximo() {
        if (i >= s.length()) throw erro("o texto terminou antes do fim do objeto");
        return s.charAt(i);
    }

    private char ler() {
        char c = proximo();
        i++;
        return c;
    }

    private void esperar(char esperado) {
        if (ler() != esperado) throw erro("esperava " + esperado + " na posição " + (i - 1));
    }

    private void espaco() {
        while (i < s.length() && (s.charAt(i) == ' ' || s.charAt(i) == '\n' || s.charAt(i) == '\r' || s.charAt(i) == '\t')) i++;
    }

    private String texto() {
        esperar('"');
        StringBuilder b = new StringBuilder();
        while (true) {
            char c = ler();
            if (c == '"') return b.toString();
            if (c < 0x20) throw erro("caractere de controle dentro do texto");
            if (c != '\\') {
                b.append(c);
                continue;
            }
            char e = ler();
            switch (e) {
                case '"', '\\', '/' -> b.append(e);
                case 'n' -> b.append('\n');
                case 'r' -> b.append('\r');
                case 't' -> b.append('\t');
                case 'u' -> {
                    if (i + 4 > s.length()) throw erro("sequência \\u incompleta");
                    try {
                        b.append((char) Integer.parseInt(s.substring(i, i + 4), 16));
                    } catch (NumberFormatException ex) {
                        throw erro("sequência \\u inválida");
                    }
                    i += 4;
                }
                default -> throw erro("escape desconhecido \\" + e);
            }
        }
    }

    private Object valor() {
        char c = proximo();
        if (c == '"') return texto();
        if (s.startsWith("true", i)) { i += 4; return Boolean.TRUE; }
        if (s.startsWith("false", i)) { i += 5; return Boolean.FALSE; }
        if (s.startsWith("null", i)) { i += 4; return null; }
        int inicio = i;
        if (c == '-') i++;
        int digitos = i;
        while (i < s.length() && Character.isDigit(s.charAt(i))) i++;
        if (i == digitos) throw erro("valor inesperado na posição " + inicio);
        boolean decimal = false;
        if (i < s.length() && s.charAt(i) == '.') {
            decimal = true;
            i++;
            int fracao = i;
            while (i < s.length() && Character.isDigit(s.charAt(i))) i++;
            if (i == fracao) throw erro("número incompleto na posição " + inicio);
        }
        String numero = s.substring(inicio, i);
        try {
            return decimal ? (Object) Double.valueOf(numero) : (Object) Integer.valueOf(numero);
        } catch (NumberFormatException ex) {
            throw erro("número fora do limite: " + numero);
        }
    }
}
