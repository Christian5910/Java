package br.estudo;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import java.io.IOException;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Infraestrutura do laboratório: um serviço de estoque em memória, só em 127.0.0.1, com falhas injetáveis.
 * Não é o seu trabalho e não é um modelo de produção (sem autenticação, sem persistência, chave de operação
 * sem escopo de usuário).
 *
 *   GET  /itens/{id}                  200 {"id":"A","quantidade":5,"versao":1}  |  404
 *   POST /itens/{id}/retiradas        cabeçalho Chave-Operacao; corpo {"quantidade":2,"versao":1}
 *                                     200 {"retirado":2,"quantidade":3,"versao":2}   (cabeçalho Repetida: true|false)
 *                                     409 versão antiga ou chave já usada com outro conteúdo | 422 estoque insuficiente
 *   POST /_falha?modo=lento|invalido|perder|nenhum   escolhe a falha (para experimentar com curl). Em "perder", a
 *                                     próxima retirada é feita e a resposta nunca chega (uma única vez); as consultas
 *                                     perdem a resposta enquanto o modo estiver ativo.
 *   GET  /_estado                     o estoque atual
 */
public final class Servidor implements AutoCloseable {
    public enum Modo { NENHUM, LENTO, JSON_INVALIDO, PERDER_RESPOSTA }

    private record Registro(int quantidade, int versao, String resposta) {}

    private final HttpServer http;
    private final long atrasoMs;
    private final Map<String, int[]> itens = new LinkedHashMap<>();       // id -> {quantidade, versao}
    private final Map<String, Registro> operacoes = new HashMap<>();      // chave -> pedido e resposta confirmada
    private final AtomicInteger requisicoes = new AtomicInteger();
    private volatile Modo modo = Modo.NENHUM;

    private Servidor(int porta, long atrasoMs) throws IOException {
        this.atrasoMs = atrasoMs;
        this.http = HttpServer.create(new InetSocketAddress(InetAddress.getLoopbackAddress(), porta), 0);
        this.http.createContext("/", this::tratar);
        this.http.setExecutor(Executors.newCachedThreadPool(r -> {
            Thread t = new Thread(r, "servidor-estoque");
            t.setDaemon(true);
            return t;
        }));
        reiniciar();
    }

    /** Porta 0 escolhe uma porta temporária. atrasoMs é a espera do modo LENTO. */
    public static Servidor iniciar(int porta, long atrasoMs) throws IOException {
        Servidor servidor = new Servidor(porta, atrasoMs);
        servidor.http.start();
        return servidor;
    }

    public static void main(String[] args) throws Exception {
        int porta = args.length > 0 ? Integer.parseInt(args[0]) : 8080;
        Servidor servidor = iniciar(porta, 3000);
        System.out.println("Estoque em http://127.0.0.1:" + servidor.porta() + "  (Ctrl+C encerra)");
        Thread.currentThread().join();
    }

    public int porta() {
        return http.getAddress().getPort();
    }

    public void modo(Modo novo) {
        this.modo = novo;
    }

    public synchronized void reiniciar() {
        itens.clear();
        itens.put("A", new int[] {5, 1});
        itens.put("B", new int[] {0, 1});
        operacoes.clear();
        requisicoes.set(0);
        modo = Modo.NENHUM;
    }

    public synchronized int quantidade(String id) {
        return itens.get(id)[0];
    }

    public synchronized int versao(String id) {
        return itens.get(id)[1];
    }

    public int requisicoes() {
        return requisicoes.get();
    }

    @Override
    public void close() {
        http.stop(0);
    }

    // ------------------------------------------------------------------ rotas

    private void tratar(HttpExchange t) throws IOException {
        requisicoes.incrementAndGet();
        try {
            String caminho = t.getRequestURI().getPath();
            String metodo = t.getRequestMethod();
            if (caminho.equals("/_falha") && metodo.equals("POST")) {
                String texto = String.valueOf(parametro(t.getRequestURI().getRawQuery(), "modo"));
                modo = switch (texto) {
                    case "lento" -> Modo.LENTO;
                    case "invalido" -> Modo.JSON_INVALIDO;
                    case "perder" -> Modo.PERDER_RESPOSTA;
                    default -> Modo.NENHUM;
                };
                responder(t, 204, null, null);
                return;
            }
            if (caminho.equals("/_estado") && metodo.equals("GET")) {
                responder(t, 200, estado(), null);
                return;
            }
            String[] p = caminho.split("/");
            if (p.length == 3 && p[1].equals("itens") && metodo.equals("GET")) {
                consultar(t, decodificar(p[2]));
            } else if (p.length == 4 && p[1].equals("itens") && p[3].equals("retiradas") && metodo.equals("POST")) {
                retirar(t, decodificar(p[2]));
            } else {
                responder(t, 404, "{\"erro\":\"rota\"}", null);
            }
        } finally {
            t.close(); // sem resposta enviada, fechar encerra a conexão: é assim que a resposta se "perde"
        }
    }

    private void consultar(HttpExchange t, String id) throws IOException {
        int[] item;
        synchronized (this) {
            item = itens.containsKey(id) ? itens.get(id).clone() : null;
        }
        if (item == null) {
            responder(t, 404, "{\"erro\":\"nao-encontrado\"}", null);
            return;
        }
        Modo atual = modo;
        if (atual == Modo.PERDER_RESPOSTA) return;                  // consulta sem resposta: a conexão é fechada
        if (atual == Modo.LENTO) dormir(atrasoMs);
        if (atual == Modo.JSON_INVALIDO) {
            responder(t, 200, "{\"id\":" + Json.escapar(id) + ",\"quantidade\":" + item[0] + ",\"versao\"", null);
            return;
        }
        responder(t, 200, "{\"id\":" + Json.escapar(id) + ",\"quantidade\":" + item[0] + ",\"versao\":" + item[1] + "}", null);
    }

    private void retirar(HttpExchange t, String id) throws IOException {
        String chave = t.getRequestHeaders().getFirst("Chave-Operacao");
        if (chave == null || chave.isBlank()) {
            responder(t, 400, "{\"erro\":\"chave-ausente\"}", null);
            return;
        }
        int quantidade, versao;
        try {
            Map<String, Object> corpo = Json.objeto(new String(t.getRequestBody().readAllBytes(), StandardCharsets.UTF_8));
            quantidade = Json.inteiro(corpo, "quantidade");
            versao = Json.inteiro(corpo, "versao");
        } catch (IllegalArgumentException e) {
            responder(t, 400, "{\"erro\":\"corpo-invalido\"}", null);
            return;
        }
        int status;
        String resposta;
        boolean repetida = false;
        Modo atual;
        synchronized (this) {
            atual = modo;
            Registro anterior = operacoes.get(chave);
            int[] item = itens.get(id);
            if (anterior != null) {
                if (anterior.quantidade() == quantidade && anterior.versao() == versao) {
                    status = 200;
                    resposta = anterior.resposta();
                    repetida = true;
                } else {
                    status = 409;
                    resposta = "{\"erro\":\"chave-reutilizada\"}";
                }
            } else if (item == null) {
                status = 404;
                resposta = "{\"erro\":\"nao-encontrado\"}";
            } else if (item[1] != versao) {
                status = 409;
                resposta = "{\"erro\":\"versao\",\"atual\":" + item[1] + "}";
            } else if (quantidade <= 0 || quantidade > item[0]) {
                status = 422;
                resposta = "{\"erro\":\"insuficiente\",\"quantidade\":" + item[0] + "}";
            } else {
                item[0] -= quantidade;
                item[1]++;
                status = 200;
                resposta = "{\"retirado\":" + quantidade + ",\"quantidade\":" + item[0] + ",\"versao\":" + item[1] + "}";
                operacoes.put(chave, new Registro(quantidade, versao, resposta));
                if (atual == Modo.PERDER_RESPOSTA) modo = Modo.NENHUM; // a falha acontece uma única vez
            }
        }
        // Daqui em diante o efeito já está confirmado no servidor, aconteça o que acontecer com a resposta.
        if (atual == Modo.LENTO) dormir(atrasoMs);                  // serviço lento: toda resposta demora, inclusive repetições
        if (status == 200 && !repetida) {
            if (atual == Modo.PERDER_RESPOSTA) return;             // não responde: a conexão é fechada
            if (atual == Modo.JSON_INVALIDO) {
                responder(t, 200, resposta.substring(0, resposta.length() - 8), null);
                return;
            }
        }
        responder(t, status, resposta, status == 200 ? Boolean.valueOf(repetida) : null);
    }

    // ----------------------------------------------------------------- apoio

    private synchronized String estado() {
        StringBuilder b = new StringBuilder("{");
        for (Map.Entry<String, int[]> e : itens.entrySet()) {
            if (b.length() > 1) b.append(',');
            b.append(Json.escapar(e.getKey())).append(":{\"quantidade\":").append(e.getValue()[0]).append(",\"versao\":").append(e.getValue()[1]).append('}');
        }
        return b.append('}').toString();
    }

    /** repetida: true ou false acrescenta o cabeçalho Repetida; null não o envia. */
    private void responder(HttpExchange t, int status, String corpo, Boolean repetida) throws IOException {
        if (repetida != null) t.getResponseHeaders().set("Repetida", repetida.toString());
        t.getResponseHeaders().set("Content-Type", "application/json; charset=utf-8");
        if (corpo == null) {
            t.sendResponseHeaders(status, -1);
            return;
        }
        byte[] bytes = corpo.getBytes(StandardCharsets.UTF_8);
        t.sendResponseHeaders(status, bytes.length);
        try (OutputStream saida = t.getResponseBody()) {
            saida.write(bytes);
        }
    }

    private static String parametro(String consulta, String nome) {
        if (consulta == null) return null;
        for (String par : consulta.split("&")) {
            String[] kv = par.split("=", 2);
            if (kv[0].equals(nome) && kv.length == 2) return decodificar(kv[1]);
        }
        return null;
    }

    private static String decodificar(String texto) {
        return URLDecoder.decode(texto, StandardCharsets.UTF_8);
    }

    private static void dormir(long ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
