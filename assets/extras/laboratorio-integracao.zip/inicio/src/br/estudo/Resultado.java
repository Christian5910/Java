package br.estudo;

/** O que o chamador precisa saber: a situação, uma mensagem para a pessoa e, quando houver, os números. */
public record Resultado(Situacao situacao, String mensagem, int quantidade, int versao, boolean repetida) {
    public static Resultado ok(int quantidade, int versao, boolean repetida) {
        return new Resultado(Situacao.OK, "OK", quantidade, versao, repetida);
    }

    public static Resultado falha(Situacao situacao, String mensagem) {
        return new Resultado(situacao, mensagem, -1, -1, false);
    }
}
