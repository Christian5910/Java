package br.estudo;

/** Resultado de uma chamada ao serviço, do ponto de vista de quem chamou. */
public enum Situacao {
    OK,                 // o serviço respondeu e o corpo foi lido
    NAO_ENCONTRADO,     // o serviço respondeu: o item não existe
    CONEXAO_RECUSADA,   // não foi possível conectar: nada foi enviado
    TEMPO_ESGOTADO,     // consulta sem resposta no prazo
    FALHA_DE_REDE,      // outro erro de transporte numa consulta
    RESPOSTA_INVALIDA,  // o serviço respondeu, mas a resposta não pôde ser lida ou não era esperada
    CONFLITO,           // 409: versão antiga ou chave de operação já usada com outro conteúdo
    INSUFICIENTE,       // 422: quantidade maior que o estoque
    DESCONHECIDO,       // retirada enviada, resultado não conhecido (tempo esgotado ou conexão perdida)
    DESATUALIZADO       // reservado ao desafio D2: último valor conhecido, não confirmado agora
}
