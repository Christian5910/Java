package br.estudo;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.ServerSocket;
import java.net.URI;
import java.time.Duration;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Verifica o contrato do seu ClienteEstoque contra um servidor de verdade (127.0.0.1, porta temporária) em que
 * as falhas são provocadas: resposta lenta, JSON inválido, resposta perdida depois da confirmação, conexão recusada.
 * Mede tempo e confere o estado do servidor. Não é uma nota: cada linha diz o que foi conferido.
 *
 * Uso:  java -cp out br.estudo.VerificarCliente                 (etapas 2 a 4)
 *       java -cp out br.estudo.VerificarCliente orcamento       (desafio D1)
 *       java -cp out br.estudo.VerificarCliente desatualizado   (desafio D2)
 */
public class VerificarCliente {
    private static final Duration TIMEOUT = Duration.ofMillis(500);
    private static final long ATRASO_MS = 2000;

    private interface Corpo {
        void executar() throws Exception;
    }

    private static final List<String> FALHAS = new ArrayList<>();
    private static final Set<String> CAUSAS = new HashSet<>();
    private static int passaram = 0;
    private static Servidor servidor;
    private static ClienteEstoque cliente;
    private static ClienteEstoque semServico;
    private static String urlDoServico;
    private static final Resultado[] CONSULTA = new Resultado[5]; // 0 nao encontrado, 1 recusada, 2 lenta, 3 json invalido, 4 conexao perdida
    private static final Resultado[] RETIRADA = new Resultado[5]; // 0 desconhecido, 1 recusada, 2 versao, 3 chave, 4 insuficiente

    public static void main(String[] args) throws Exception {
        String modo = args.length > 0 ? args[0] : "";
        servidor = Servidor.iniciar(0, ATRASO_MS);
        urlDoServico = "http://127.0.0.1:" + servidor.porta();
        cliente = new ClienteEstoque(URI.create(urlDoServico), TIMEOUT);
        semServico = new ClienteEstoque(URI.create("http://127.0.0.1:" + portaFechada()), TIMEOUT);
        aquecer();

        if (modo.isEmpty()) {
            verificarConsulta();
            verificarRetirada();
        } else if (modo.equals("orcamento")) {
            verificarOrcamento();
        } else if (modo.equals("desatualizado")) {
            verificarDesatualizado();
        } else {
            System.out.println("Modo desconhecido: " + modo + ". Use orcamento, desatualizado ou nenhum argumento.");
            System.exit(2);
        }

        int total = passaram + FALHAS.size();
        for (String falha : FALHAS) System.out.println("FALHA  " + falha);
        System.out.println(passaram + " de " + total + " verificações de cliente passaram.");
        System.out.println("NÃO VERIFICADO por este programa (rede real e produção):");
        System.out.println("  - latência variável, perda de pacotes, DNS e TLS; só há loopback com falhas simuladas e determinísticas.");
        System.out.println("  - vários clientes ao mesmo tempo com a mesma chave, retenção das chaves e escopo por usuário.");
        System.out.println("  - fila de tarefas de fundo ou thread gráfica: aqui o cliente é chamado direto, de um programa de console.");
        servidor.close();
        System.exit(FALHAS.isEmpty() ? 0 : 1);
    }

    // -------------------------------------------------------------- consulta

    private static void verificarConsulta() {
        verificar("consultar o item A devolve OK, quantidade 5 e versão 1", () -> {
            reiniciar();
            Resultado r = cliente.consultar("A");
            exigir(r.situacao() == Situacao.OK, "esperava OK, veio " + r.situacao() + " (" + r.mensagem() + ")");
            exigir(r.quantidade() == 5 && r.versao() == 1, "esperava quantidade 5 e versão 1, veio " + r.quantidade() + " e " + r.versao());
        });
        verificar("item inexistente dá NAO_ENCONTRADO", () -> {
            reiniciar();
            Resultado r = cliente.consultar("Z");
            exigir(r.situacao() == Situacao.NAO_ENCONTRADO, "esperava NAO_ENCONTRADO, veio " + r.situacao());
            CONSULTA[0] = r;
        });
        verificar("conexão recusada dá CONEXAO_RECUSADA, sem travar", () -> {
            long inicio = System.nanoTime();
            Resultado r = semServico.consultar("A");
            exigir(r.situacao() == Situacao.CONEXAO_RECUSADA, "esperava CONEXAO_RECUSADA, veio " + r.situacao());
            exigir(ms(inicio) < 2000, "demorou " + ms(inicio) + " ms para perceber que não há serviço");
            CONSULTA[1] = r;
        });
        verificar("conexão perdida numa consulta dá FALHA_DE_REDE, nunca NAO_ENCONTRADO", () -> {
            reiniciar();
            servidor.modo(Servidor.Modo.PERDER_RESPOSTA);
            Resultado r = cliente.consultar("A");
            exigir(r.situacao() == Situacao.FALHA_DE_REDE, "esperava FALHA_DE_REDE, veio " + r.situacao() + " (" + r.mensagem() + ")");
            CONSULTA[4] = r;
        });
        verificar("resposta lenta dá TEMPO_ESGOTADO antes de a resposta chegar", () -> {
            reiniciar();
            servidor.modo(Servidor.Modo.LENTO);
            long inicio = System.nanoTime();
            Resultado r = cliente.consultar("A");
            long gasto = ms(inicio);
            exigir(r.situacao() == Situacao.TEMPO_ESGOTADO, "esperava TEMPO_ESGOTADO, veio " + r.situacao() + " (" + r.mensagem() + ")");
            exigir(gasto < ATRASO_MS - 300, "esperou " + gasto + " ms: o limite de " + TIMEOUT.toMillis() + " ms não foi aplicado à resposta");
            CONSULTA[2] = r;
        });
        verificar("JSON inválido dá RESPOSTA_INVALIDA", () -> {
            reiniciar();
            servidor.modo(Servidor.Modo.JSON_INVALIDO);
            Resultado r = cliente.consultar("A");
            exigir(r.situacao() == Situacao.RESPOSTA_INVALIDA, "esperava RESPOSTA_INVALIDA, veio " + r.situacao() + " (" + r.mensagem() + ")");
            CONSULTA[3] = r;
        });
        verificar("as cinco situações de consulta têm mensagens diferentes e não vazias", () -> distintas(CONSULTA, "consulta"));
    }

    // -------------------------------------------------------------- retirada

    private static void verificarRetirada() {
        verificar("retirar sem chave é recusado antes de enviar (IllegalArgumentException, nenhuma requisição)", () -> {
            reiniciar();
            for (String chave : new String[] {null, "", "   "}) {
                try {
                    cliente.retirar("A", 1, 1, chave);
                } catch (IllegalArgumentException esperado) {
                    continue;
                }
                throw new AssertionError("aceitou a chave " + (chave == null ? "nula" : "\"" + chave + "\""));
            }
            exigir(servidor.requisicoes() == 0, "enviou " + servidor.requisicoes() + " requisição(ões) sem chave de operação");
        });
        verificar("retirada confirmada: OK com quantidade 3 e versão 2, e o servidor descontou 2", () -> {
            reiniciar();
            Resultado r = cliente.retirar("A", 2, 1, "k-ok");
            exigir(r.situacao() == Situacao.OK, "esperava OK, veio " + r.situacao() + " (" + r.mensagem() + ")");
            exigir(r.quantidade() == 3 && r.versao() == 2 && !r.repetida(), "esperava 3, versão 2, não repetida; veio " + r);
            exigir(servidor.quantidade("A") == 3, "o servidor ficou com " + servidor.quantidade("A"));
        });
        verificar("repetir a mesma chave e o mesmo conteúdo devolve o resultado, marcado repetida, sem descontar de novo", () -> {
            reiniciar();
            cliente.retirar("A", 2, 1, "k-rep");
            Resultado r = cliente.retirar("A", 2, 1, "k-rep");
            exigir(r.situacao() == Situacao.OK && r.repetida(), "esperava OK repetida, veio " + r);
            exigir(r.quantidade() == 3 && servidor.quantidade("A") == 3, "descontou de novo: o servidor ficou com " + servidor.quantidade("A"));
        });
        verificar("a mesma chave com outro conteúdo dá CONFLITO e não altera o estoque", () -> {
            reiniciar();
            cliente.retirar("A", 2, 1, "k-mesma");
            Resultado r = cliente.retirar("A", 1, 1, "k-mesma");
            exigir(r.situacao() == Situacao.CONFLITO, "esperava CONFLITO, veio " + r.situacao());
            exigir(servidor.quantidade("A") == 3, "o servidor ficou com " + servidor.quantidade("A"));
            RETIRADA[3] = r;
        });
        verificar("versão antiga dá CONFLITO, com mensagem diferente da chave reutilizada", () -> {
            reiniciar();
            cliente.retirar("A", 2, 1, "k-v1");
            Resultado r = cliente.retirar("A", 1, 1, "k-v2");
            exigir(r.situacao() == Situacao.CONFLITO, "esperava CONFLITO, veio " + r.situacao());
            exigir(servidor.quantidade("A") == 3, "o servidor ficou com " + servidor.quantidade("A"));
            RETIRADA[2] = r;
            exigir(RETIRADA[3] == null || !r.mensagem().equals(RETIRADA[3].mensagem()), "a mensagem é igual à da chave reutilizada");
        });
        verificar("quantidade acima do estoque dá INSUFICIENTE e não altera o estoque", () -> {
            reiniciar();
            Resultado r = cliente.retirar("A", 99, 1, "k-muito");
            exigir(r.situacao() == Situacao.INSUFICIENTE, "esperava INSUFICIENTE, veio " + r.situacao());
            exigir(servidor.quantidade("A") == 5, "o servidor ficou com " + servidor.quantidade("A"));
            RETIRADA[4] = r;
        });
        verificar("conexão recusada na retirada dá CONEXAO_RECUSADA (nada foi enviado)", () -> {
            Resultado r = semServico.retirar("A", 1, 1, "k-sem");
            exigir(r.situacao() == Situacao.CONEXAO_RECUSADA, "esperava CONEXAO_RECUSADA, veio " + r.situacao());
            RETIRADA[1] = r;
        });
        verificar("resposta perdida depois da confirmação dá DESCONHECIDO; repetir a chave descobre o resultado sem descontar de novo", () -> {
            reiniciar();
            servidor.modo(Servidor.Modo.PERDER_RESPOSTA);
            Resultado r = cliente.retirar("A", 1, 1, "k-perdida");
            exigir(r.situacao() == Situacao.DESCONHECIDO, "esperava DESCONHECIDO, veio " + r.situacao() + " (" + r.mensagem() + ")");
            exigir(servidor.quantidade("A") == 4, "o servidor deveria ter aplicado a retirada (4), mas tem " + servidor.quantidade("A"));
            RETIRADA[0] = r;
            Resultado depois = cliente.retirar("A", 1, 1, "k-perdida");
            exigir(depois.situacao() == Situacao.OK && depois.repetida() && depois.quantidade() == 4, "esperava OK repetida com 4, veio " + depois);
            exigir(servidor.quantidade("A") == 4, "descontou de novo: o servidor ficou com " + servidor.quantidade("A"));
        });
        verificar("resposta lenta na retirada dá DESCONHECIDO; repetir a chave não desconta de novo", () -> {
            reiniciar();
            servidor.modo(Servidor.Modo.LENTO);
            long inicio = System.nanoTime();
            Resultado r = cliente.retirar("A", 1, 1, "k-lenta");
            exigir(r.situacao() == Situacao.DESCONHECIDO, "esperava DESCONHECIDO, veio " + r.situacao() + " (" + r.mensagem() + ")");
            exigir(ms(inicio) < ATRASO_MS - 300, "esperou " + ms(inicio) + " ms: o limite de resposta não foi aplicado");
            exigir(servidor.quantidade("A") == 4, "o servidor deveria ter aplicado a retirada (4), mas tem " + servidor.quantidade("A"));
            servidor.modo(Servidor.Modo.NENHUM);
            Resultado depois = cliente.retirar("A", 1, 1, "k-lenta");
            exigir(depois.situacao() == Situacao.OK && depois.repetida() && depois.quantidade() == 4, "esperava OK repetida com 4, veio " + depois);
            exigir(servidor.quantidade("A") == 4, "descontou de novo: o servidor ficou com " + servidor.quantidade("A"));
        });
        verificar("JSON inválido na retirada dá RESPOSTA_INVALIDA; repetir a chave lê o resultado sem descontar de novo", () -> {
            reiniciar();
            servidor.modo(Servidor.Modo.JSON_INVALIDO);
            Resultado r = cliente.retirar("A", 1, 1, "k-ilegivel");
            exigir(r.situacao() == Situacao.RESPOSTA_INVALIDA, "esperava RESPOSTA_INVALIDA, veio " + r.situacao() + " (" + r.mensagem() + ")");
            exigir(servidor.quantidade("A") == 4, "o servidor deveria ter aplicado a retirada (4), mas tem " + servidor.quantidade("A"));
            servidor.modo(Servidor.Modo.NENHUM);
            Resultado depois = cliente.retirar("A", 1, 1, "k-ilegivel");
            exigir(depois.situacao() == Situacao.OK && depois.repetida() && depois.quantidade() == 4, "esperava OK repetida com 4, veio " + depois);
            exigir(servidor.quantidade("A") == 4, "descontou de novo: o servidor ficou com " + servidor.quantidade("A"));
        });
        verificar("as mensagens de retirada (desconhecido, recusada, versão, chave, insuficiente) são diferentes entre si", () -> distintas(RETIRADA, "retirada"));
    }

    // ---------------------------------------------------- desafio D1: orçamento

    private static void verificarOrcamento() {
        Class<?>[] tipos = {String.class, int.class, int.class, String.class, Duration.class};
        verificar("D1: com a primeira resposta perdida, a segunda tentativa (mesma chave) confirma dentro do orçamento", () -> {
            reiniciar();
            servidor.modo(Servidor.Modo.PERDER_RESPOSTA);
            long inicio = System.nanoTime();
            Resultado r = chamar(cliente, "retirarComTentativas", tipos, "A", 1, 1, "k-orc1", Duration.ofSeconds(3));
            exigir(r.situacao() == Situacao.OK && r.repetida() && r.quantidade() == 4, "esperava OK repetida com 4, veio " + r);
            exigir(servidor.quantidade("A") == 4, "o servidor ficou com " + servidor.quantidade("A") + ": a mesma chave deve valer em todas as tentativas");
            exigir(ms(inicio) < 3000, "passou do orçamento de 3000 ms: " + ms(inicio) + " ms");
        });
        verificar("D1: com o serviço sempre lento, para ao esgotar o orçamento e devolve DESCONHECIDO", () -> {
            reiniciar();
            servidor.modo(Servidor.Modo.LENTO);
            long inicio = System.nanoTime();
            Resultado r = chamar(cliente, "retirarComTentativas", tipos, "A", 1, 1, "k-orc2", Duration.ofMillis(1200));
            long gasto = ms(inicio);
            exigir(r.situacao() == Situacao.DESCONHECIDO, "esperava DESCONHECIDO, veio " + r.situacao() + " (" + r.mensagem() + ")");
            exigir(gasto <= 1200 + 350, "gastou " + gasto + " ms com um orçamento de 1200 ms: cada tentativa deve caber no que resta");
            exigir(servidor.quantidade("A") == 4, "o servidor ficou com " + servidor.quantidade("A") + ": só uma retirada deve ter sido aplicada");
        });
        verificar("D1: com conexão recusada, devolve CONEXAO_RECUSADA dentro do orçamento", () -> {
            long inicio = System.nanoTime();
            Resultado r = chamar(semServico, "retirarComTentativas", tipos, "A", 1, 1, "k-orc3", Duration.ofMillis(1000));
            exigir(r.situacao() == Situacao.CONEXAO_RECUSADA, "esperava CONEXAO_RECUSADA, veio " + r.situacao());
            exigir(ms(inicio) <= 1000 + 350, "gastou " + ms(inicio) + " ms com um orçamento de 1000 ms");
        });
    }

    // ---------------------------------------------- desafio D2: dado desatualizado

    private static void verificarDesatualizado() {
        Class<?>[] tipo = {String.class};
        verificar("D2: sem valor anterior, a falha continua sendo falha (nunca zero nem lista vazia)", () -> {
            ClienteEstoque novo = new ClienteEstoque(URI.create("http://127.0.0.1:" + portaFechada()), TIMEOUT);
            Resultado r = chamar(novo, "consultarComUltimoValor", tipo, "A");
            exigir(r.situacao() == Situacao.CONEXAO_RECUSADA, "esperava CONEXAO_RECUSADA, veio " + r.situacao());
        });
        verificar("D2: com valor anterior, a falha devolve DESATUALIZADO com a última quantidade e versão", () -> {
            reiniciar();
            ClienteEstoque novo = new ClienteEstoque(URI.create(urlDoServico), TIMEOUT);
            Resultado primeiro = chamar(novo, "consultarComUltimoValor", tipo, "A");
            exigir(primeiro.situacao() == Situacao.OK && primeiro.quantidade() == 5, "a primeira consulta deveria ser OK com 5, veio " + primeiro);
            servidor.modo(Servidor.Modo.LENTO);
            Resultado r = chamar(novo, "consultarComUltimoValor", tipo, "A");
            exigir(r.situacao() == Situacao.DESATUALIZADO, "esperava DESATUALIZADO, veio " + r.situacao() + " (" + r.mensagem() + ")");
            exigir(r.quantidade() == 5 && r.versao() == 1, "esperava os últimos valores 5 e 1, veio " + r.quantidade() + " e " + r.versao());
            exigir(r.mensagem().toLowerCase().contains("desatualizado"), "a mensagem deve dizer que o dado está desatualizado: " + r.mensagem());
        });
        verificar("D2: o valor de um item não aparece no lugar de outro", () -> {
            reiniciar();
            ClienteEstoque novo = new ClienteEstoque(URI.create(urlDoServico), TIMEOUT);
            chamar(novo, "consultarComUltimoValor", tipo, "A");
            servidor.modo(Servidor.Modo.LENTO);
            Resultado r = chamar(novo, "consultarComUltimoValor", tipo, "B");
            exigir(r.situacao() == Situacao.TEMPO_ESGOTADO, "esperava TEMPO_ESGOTADO para o item B, veio " + r.situacao());
        });
        verificar("D2: item inexistente continua NAO_ENCONTRADO, mesmo havendo valores guardados", () -> {
            reiniciar();
            ClienteEstoque novo = new ClienteEstoque(URI.create(urlDoServico), TIMEOUT);
            chamar(novo, "consultarComUltimoValor", tipo, "A");
            Resultado r = chamar(novo, "consultarComUltimoValor", tipo, "Z");
            exigir(r.situacao() == Situacao.NAO_ENCONTRADO, "esperava NAO_ENCONTRADO, veio " + r.situacao());
        });
        verificar("D2: quando o serviço volta, o valor novo substitui o antigo", () -> {
            reiniciar();
            ClienteEstoque novo = new ClienteEstoque(URI.create(urlDoServico), TIMEOUT);
            chamar(novo, "consultarComUltimoValor", tipo, "A");
            novo.retirar("A", 1, 1, "k-d2");
            Resultado r = chamar(novo, "consultarComUltimoValor", tipo, "A");
            exigir(r.situacao() == Situacao.OK && r.quantidade() == 4 && r.versao() == 2, "esperava OK com 4 e versão 2, veio " + r);
        });
    }

    // ----------------------------------------------------------------- apoio

    private static void verificar(String nome, Corpo corpo) {
        try {
            corpo.executar();
            passaram++;
        } catch (Throwable erro) {
            Throwable causa = erro instanceof InvocationTargetException && erro.getCause() != null ? erro.getCause() : erro;
            String detalhe = causa.getMessage() != null ? causa.getMessage() : causa.getClass().getSimpleName();
            if (!(causa instanceof AssertionError)) detalhe = causa.getClass().getSimpleName() + ": " + detalhe;
            FALHAS.add(nome + " -> " + (CAUSAS.add(detalhe) ? detalhe : "(mesma causa da falha anterior)"));
        } finally {
            servidor.modo(Servidor.Modo.NENHUM);
        }
    }

    private static void exigir(boolean condicao, String mensagem) {
        if (!condicao) throw new AssertionError(mensagem);
    }

    private static void distintas(Resultado[] resultados, String grupo) {
        Set<String> vistas = new HashSet<>();
        for (Resultado r : resultados) {
            exigir(r != null, "depende das verificações anteriores de " + grupo + ", que falharam");
            exigir(r.mensagem() != null && !r.mensagem().isBlank(), "há uma mensagem vazia: " + r.situacao());
            exigir(vistas.add(r.mensagem()), "duas situações usam a mesma mensagem: \"" + r.mensagem() + "\"");
        }
    }

    private static Resultado chamar(Object alvo, String metodo, Class<?>[] tipos, Object... argumentos) throws Exception {
        Method m;
        try {
            m = alvo.getClass().getMethod(metodo, tipos);
        } catch (NoSuchMethodException e) {
            StringBuilder assinatura = new StringBuilder();
            for (Class<?> t : tipos) assinatura.append(assinatura.length() > 0 ? ", " : "").append(t.getSimpleName());
            throw new AssertionError("ClienteEstoque não tem o método público " + metodo + "(" + assinatura + ")");
        }
        try {
            return (Resultado) m.invoke(alvo, argumentos);
        } catch (InvocationTargetException e) {
            throw e.getCause() instanceof Exception ex ? ex : e;
        }
    }

    /**
     * A primeira chamada de um cliente paga o carregamento de classes e a primeira conexão. Sem este aquecimento,
     * uma máquina lenta ou ocupada veria TEMPO_ESGOTADO já na primeira verificação, por partida a frio e não por defeito.
     */
    private static void aquecer() {
        try {
            new ClienteEstoque(URI.create(urlDoServico), Duration.ofSeconds(5)).consultar("A");
            new ClienteEstoque(URI.create(urlDoServico), Duration.ofSeconds(5)).retirar("A", 1, 99, "aquecimento");
        } catch (Throwable ignorado) {
            // o ponto de partida ainda não implementa os métodos; as verificações vão dizer isso
        }
        servidor.reiniciar();
    }

    private static void reiniciar() {
        servidor.reiniciar();
    }

    private static long ms(long inicioNanos) {
        return (System.nanoTime() - inicioNanos) / 1_000_000;
    }

    private static int portaFechada() throws Exception {
        try (ServerSocket s = new ServerSocket(0)) {
            return s.getLocalPort();
        }
    }
}
