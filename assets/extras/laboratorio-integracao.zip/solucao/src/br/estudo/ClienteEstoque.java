package br.estudo;

import java.io.IOException;
import java.net.ConnectException;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpConnectTimeoutException;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpTimeoutException;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.Map;

public class ClienteEstoque {
    private final URI base;
    private final Duration timeout;
    private final HttpClient http;

    public ClienteEstoque(URI base, Duration timeout) {
        this.base = base;
        this.timeout = timeout;
        // HTTP/1.1: o servidor do laboratório só fala essa versão; fixá-la evita a tentativa de upgrade para HTTP/2 e
        // deixa o comportamento previsível. O limite de conexão e o de resposta (no pedido) são separados.
        this.http = HttpClient.newBuilder().version(HttpClient.Version.HTTP_1_1).connectTimeout(timeout).build();
    }

    public Resultado consultar(String id) {
        HttpRequest pedido = HttpRequest.newBuilder(base.resolve("/itens/" + codificar(id))).timeout(timeout).GET().build();
        return enviar(pedido, false);
    }

    public Resultado retirar(String id, int quantidade, int versao, String chave) {
        if (chave == null || chave.isBlank()) throw new IllegalArgumentException("Informe a chave de operação.");
        String corpo = "{\"quantidade\":" + quantidade + ",\"versao\":" + versao + "}";
        HttpRequest pedido = HttpRequest.newBuilder(base.resolve("/itens/" + codificar(id) + "/retiradas"))
            .timeout(timeout)
            .header("Content-Type", "application/json")
            .header("Chave-Operacao", chave)
            .POST(HttpRequest.BodyPublishers.ofString(corpo, StandardCharsets.UTF_8))
            .build();
        return enviar(pedido, true);
    }

    private Resultado enviar(HttpRequest pedido, boolean retirada) {
        HttpResponse<String> resposta;
        try {
            resposta = http.send(pedido, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
        } catch (HttpConnectTimeoutException | ConnectException e) {
            // Nem chegou a conectar: nada foi enviado, repetir é seguro. O tipo mais específico vem primeiro.
            return Resultado.falha(Situacao.CONEXAO_RECUSADA, "Não foi possível conectar ao serviço de estoque. Nada foi enviado; tente novamente.");
        } catch (HttpTimeoutException e) {
            return retirada
                ? Resultado.falha(Situacao.DESCONHECIDO, "O serviço não respondeu a tempo. Não sabemos se a retirada foi feita; repita com a mesma chave para descobrir.")
                : Resultado.falha(Situacao.TEMPO_ESGOTADO, "O serviço demorou demais para responder. A consulta não foi concluída.");
        } catch (IOException e) {
            // Conexão perdida depois de enviar: numa retirada o efeito pode ter acontecido.
            return retirada
                ? Resultado.falha(Situacao.DESCONHECIDO, "A conexão foi perdida antes da resposta. Não sabemos se a retirada foi feita; repita com a mesma chave para descobrir.")
                : Resultado.falha(Situacao.FALHA_DE_REDE, "A conexão com o serviço foi interrompida durante a consulta.");
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return retirada
                ? Resultado.falha(Situacao.DESCONHECIDO, "A operação foi interrompida; o resultado da retirada não é conhecido.")
                : Resultado.falha(Situacao.FALHA_DE_REDE, "A consulta foi interrompida.");
        }
        return interpretar(resposta, retirada);
    }

    private Resultado interpretar(HttpResponse<String> resposta, boolean retirada) {
        int status = resposta.statusCode();
        try {
            switch (status) {
                case 200 -> {
                    Map<String, Object> json = Json.objeto(resposta.body());
                    boolean repetida = resposta.headers().firstValue("Repetida").map("true"::equals).orElse(false);
                    return Resultado.ok(Json.inteiro(json, "quantidade"), Json.inteiro(json, "versao"), repetida);
                }
                case 404 -> {
                    return Resultado.falha(Situacao.NAO_ENCONTRADO, "O item não existe no estoque.");
                }
                case 409 -> {
                    Map<String, Object> json = Json.objeto(resposta.body());
                    if ("versao".equals(json.get("erro"))) {
                        return Resultado.falha(Situacao.CONFLITO, "O item mudou desde a sua leitura (versão atual " + json.get("atual") + "). Consulte de novo antes de retirar.");
                    }
                    return Resultado.falha(Situacao.CONFLITO, "Esta chave de operação já foi usada com outro conteúdo. Gere uma chave nova para uma nova intenção.");
                }
                case 422 -> {
                    Map<String, Object> json = Json.objeto(resposta.body());
                    return Resultado.falha(Situacao.INSUFICIENTE, "Quantidade insuficiente em estoque (há " + json.get("quantidade") + ").");
                }
                default -> {
                    return Resultado.falha(Situacao.RESPOSTA_INVALIDA, "O serviço respondeu com o status inesperado " + status + ".");
                }
            }
        } catch (IllegalArgumentException e) {
            // O corpo não pôde ser lido. Numa retirada 200 isso não desfaz o efeito: não se deve repetir sem a mesma chave.
            return Resultado.falha(Situacao.RESPOSTA_INVALIDA, retirada && status == 200
                ? "O serviço confirmou, mas a resposta veio ilegível. Repita com a mesma chave para ler o resultado, sem retirar de novo."
                : "A resposta do serviço está ilegível (JSON inválido).");
        }
    }

    private static String codificar(String id) {
        return URLEncoder.encode(id, StandardCharsets.UTF_8);
    }
}
