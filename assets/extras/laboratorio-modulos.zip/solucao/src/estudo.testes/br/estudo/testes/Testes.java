package br.estudo.testes;

import br.estudo.core.Nota;

public class Testes {
    private static int total = 0;

    private static void conferir(boolean condicao, String cenario) {
        if (!condicao) throw new AssertionError(cenario);
        total++;
    }

    private static void situacao(String texto, String esperada) {
        conferir(Nota.avaliar(texto).equals(esperada), texto + " deveria dar " + esperada);
    }

    private static void recusa(String texto, String mensagem) {
        try {
            Nota.avaliar(texto);
        } catch (IllegalArgumentException esperado) {
            conferir(esperado.getMessage().equals(mensagem), "mensagem para " + texto);
            return;
        }
        throw new AssertionError("Aceitou " + texto);
    }

    public static void main(String[] args) {
        for (String texto : new String[] {"7", "10", "7,5", "  8  "}) situacao(texto, "Aprovado");
        for (String texto : new String[] {"0", "6.99", "6,5"}) situacao(texto, "Em recuperação");
        for (String texto : new String[] {null, "", "   "}) recusa(texto, "Informe a nota.");
        for (String texto : new String[] {"abc", "-1", "11", "NaN", "Infinity"}) recusa(texto, "Use um número de 0 a 10.");
        System.out.println(total + " verificações passaram.");
    }
}
