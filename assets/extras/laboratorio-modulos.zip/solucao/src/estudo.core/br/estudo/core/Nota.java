package br.estudo.core;

public final class Nota {
    private static final double MINIMA = 0;
    private static final double MAXIMA = 10;
    private static final double APROVACAO = 7;

    private Nota() {}

    /** Recebe o texto digitado, valida e devolve a situação: Aprovado ou Em recuperação. */
    public static String avaliar(String texto) {
        if (texto == null || texto.isBlank()) throw new IllegalArgumentException("Informe a nota.");
        final double valor;
        try {
            valor = Double.parseDouble(texto.trim().replace(',', '.'));
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Use um número de 0 a 10.");
        }
        if (!Double.isFinite(valor) || valor < MINIMA || valor > MAXIMA) {
            throw new IllegalArgumentException("Use um número de 0 a 10.");
        }
        return valor >= APROVACAO ? "Aprovado" : "Em recuperação";
    }
}
