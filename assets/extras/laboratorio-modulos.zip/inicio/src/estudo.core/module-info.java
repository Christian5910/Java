module estudo.core {
    exports br.estudo.core;
}
