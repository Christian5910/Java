package br.estudo.core;

public class Saudacao {
    public static void main(String[] args) {
        System.out.println("Módulo pronto");
    }
}
