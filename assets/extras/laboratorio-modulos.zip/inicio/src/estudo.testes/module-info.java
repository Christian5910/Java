module estudo.testes {
    requires estudo.core;
}
