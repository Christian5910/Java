package br.estudo.testes;

/** Ponto de partida: a verificação ainda não tem cenários. Escreva-os na etapa 3 do roteiro. */
public class Testes {
    private static int total = 0;

    private static void conferir(boolean condicao, String cenario) {
        if (!condicao) throw new AssertionError(cenario);
        total++;
    }

    public static void main(String[] args) {
        // Etapa 3: acrescente aqui os cenários de Nota.avaliar, usando conferir(...).
        System.out.println(total + " verificações passaram.");
    }
}
