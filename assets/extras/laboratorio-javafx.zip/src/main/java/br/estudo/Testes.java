package br.estudo;
public class Testes {
    public static void main(String[] args) {
        int total=0;
        for (String valor : new String[]{"7", "10", "7,5"}) {
            if (!Nota.avaliar(valor).equals("Aprovado")) throw new AssertionError(valor); total++;
        }
        for (String valor : new String[]{"0", "6.99"}) {
            if (!Nota.avaliar(valor).equals("Em recuperação")) throw new AssertionError(valor); total++;
        }
        for (String valor : new String[]{null, "", "abc", "-1", "11", "NaN", "Infinity"}) {
            try { Nota.avaliar(valor); throw new AssertionError("Aceitou " + valor); }
            catch (IllegalArgumentException esperado) { total++; }
        }
        System.out.println(total + " verificações de domínio passaram.");
    }
}
