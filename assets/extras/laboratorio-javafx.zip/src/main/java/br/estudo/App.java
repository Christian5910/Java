package br.estudo;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
public class App extends Application {
    @Override public void start(Stage palco) {
        TextField nota=new TextField(); nota.setPromptText("Ex.: 7,5");
        Label rotulo=new Label("Nota (0 a 10):");rotulo.setLabelFor(nota);
        Button conferir=new Button("Conferir");conferir.setDefaultButton(true);
        Label resultado=new Label("Informe a nota para conferir a situação.");resultado.setWrapText(true);
        conferir.disableProperty().bind(nota.textProperty().isEmpty());
        conferir.setOnAction(evento -> {
            try { resultado.setText(Nota.avaliar(nota.getText())); }
            catch (IllegalArgumentException erro) { resultado.setText(erro.getMessage());nota.requestFocus(); }
        });
        GridPane formulario=new GridPane(); formulario.setHgap(12);formulario.setVgap(12);
        formulario.add(rotulo,0,0);formulario.add(nota,1,0);formulario.add(conferir,1,1);
        GridPane.setHgrow(nota,Priority.ALWAYS);
        VBox raiz=new VBox(16,formulario,resultado);raiz.setPadding(new Insets(24));
        palco.setTitle("Notas com JavaFX");palco.setScene(new Scene(raiz,480,210));palco.show();
    }
    public static void main(String[] args) { launch(args); }
}
